local VMAPI = VoidMarkForever.API
local SM = LibStub:GetLibrary("LibSharedMedia-3.0")
local AceLocale = LibStub("AceLocale-3.0")
local L = AceLocale:GetLocale("VoidMark")
local fonts = SM:List("font")
local _

VoidMark = LibStub("AceAddon-3.0"):NewAddon("VoidMark", "AceConsole-3.0", "AceEvent-3.0", "AceTimer-3.0")
VoidMark.Version = "1.2.1"
VoidMark.DatabaseVersion = "1.1"
VoidMark.Signature = "[VoidMark]"
VoidMark.ButtonLimit = 15
VoidMark.MaximumPlayerLevel = (MAX_PLAYER_LEVEL_TABLE and GetExpansionLevel and MAX_PLAYER_LEVEL_TABLE[GetExpansionLevel()]) or 60

VoidMark.ZoneID = {}
VoidMark.KOSGuild = {}
VoidMark.CurrentList = {}
VoidMark.NearbyList = {}
VoidMark.LastHourList = {}
VoidMark.ActiveList = {}
VoidMark.InactiveList = {}
VoidMark.ListAmountDisplayed = 0
VoidMark.ButtonName = {}
VoidMark.EnabledInZone = false
VoidMark.InInstance = false
VoidMark.AlertType = nil
VoidMark.UpgradeMessageSent = false
VoidMark.zName = ""
VoidMark.ChnlTime = 0
VoidMark.Skull = -1
VoidMark.PetGUID = {}

-- Localizations for VoidMarkStats
L_STATS = "VoidMark "..L["Statistics"]
L_WON = L["Won"]
L_LOST = L["Lost"]
L_REASON = L["Reason"]
L_LIST = L["List"]
L_TIME = L["Time"]
L_FILTER = L["Filter"]..":"
L_SHOWONLY = L["Show Only"]..":"

VoidMark.options = {
	name = L["VoidMark"],
	type = "group",
	args = {
		About = {
			name = L["About"],
			desc = L["About"],
			type = "group",
			order = 1,
			args = {
				intro1 = {
					name = L["VoidMarkDescription1"],
					type = "description",
					order = 1,
					fontSize = "medium",
				},	
				intro2 = {
					name = L["VoidMarkDescription2"],
					type = "description",
					order = 2,
					fontSize = "medium",
				},
				intro3 = {
					name = L["VoidMarkDescription3"],
					type = "description",
					order = 3,
					fontSize = "medium",
				},
			},
		},
		General = {
			name = L["GeneralSettings"],
			desc = L["GeneralSettings"],
			type = "group",
			order = 1,
			args = {
				intro = {
					name = L["GeneralSettingsDescription"],
					type = "description",
					order = 1,
					fontSize = "medium",
				},
				EnabledInBattlegrounds = {
					name = L["EnabledInBattlegrounds"],
					desc = L["EnabledInBattlegroundsDescription"],
					type = "toggle",
					order = 2,
					width = "full",
					get = function(info)
						return VoidMark.db.profile.EnabledInBattlegrounds
					end,
					set = function(info, value)
						VoidMark.db.profile.EnabledInBattlegrounds = value
						VoidMark:ZoneChangedEvent()
					end,
				},
--[[				EnabledInArenas = {
					name = L["EnabledInArenas"],
					desc = L["EnabledInArenasDescription"],
					type = "toggle",
					order = 3,
					width = "full",
					get = function(info)
						return VoidMark.db.profile.EnabledInArenas
					end,
					set = function(info, value)
						VoidMark.db.profile.EnabledInArenas = value
						VoidMark:ZoneChangedEvent()
					end,
				},
				EnabledInWintergrasp = {
					name = L["EnabledInWintergrasp"],
					desc = L["EnabledInWintergraspDescription"],
					type = "toggle",
					order = 4,
					width = "full",
					get = function(info)
						return VoidMark.db.profile.EnabledInWintergrasp
					end,
					set = function(info, value)
						VoidMark.db.profile.EnabledInWintergrasp = value
						VoidMark:ZoneChangedEvent()
					end,
				}, 
				EnabledInSanctuaries = {
					name = L["EnabledInSanctuaries"],
					desc = L["EnabledInSanctuariesDescription"],
					type = "toggle",
					order = 5,
					width = "full",
					get = function(info)
						return VoidMark.db.profile.EnabledInSanctuaries
					end,
					set = function(info, value)
						VoidMark.db.profile.EnabledInSanctuaries = value
						VoidMark:ZoneChangedEvent()
					end,
				}, ]]--
				DisabledInZones = {
					name = L["DisabledInZones"],
					desc = L["DisabledInZonesDescription"],
					type = "multiselect",
					order = 7,
					get = function(info, key) 
						return VoidMark.db.profile.FilteredZones[key] 
					end,
					set = function(info, key, value) 
						VoidMark.db.profile.FilteredZones[key] = value 
					end,
					values = {
						["Booty Bay"] = L["Booty Bay"],
						["Everlook"] = L["Everlook"],
						["Gadgetzan"] = L["Gadgetzan"],
						["Ratchet"] = L["Ratchet"],
						["The Salty Sailor Tavern"] = L["The Salty Sailor Tavern"],
						["Cenarion Hold"] = L["Cenarion Hold"],
--						["Shattrath City"] = L["Shattrath City"],
--						["Area 52"] = L["Area 52"],
--						["Dalaran"] = L["Dalaran"],
--						["Bogpaddle"] = L["Bogpaddle"],
--						["The Vindicaar"] = L["The Vindicaar"],
--						["Krasus' Landing"] = L["Krasus' Landing"],
--						["The Violet Gate"] = L["The Violet Gate"],
--						["Magni's Encampment"] = L["Magni's Encampment"],
--						["Chamber of Heart"] = L["Chamber of Heart"],
--						["Hall of Ancient Paths"] = L["Hall of Ancient Paths"],
--						["Sanctum of the Sages"] = L["Sanctum of the Sages"],
--						["Rustbolt"] = L["Rustbolt"],
--						["Oribos"] = L["Oribos"],
--						["Valdrakken"] = L["Valdrakken"],
--						["The Roasted Ram"] = L["The Roasted Ram"],
--						["Dornogal"] = L["Dornogal"],						
--						["Stonelight Rest"] = L["Stonelight Rest"],
--						["Delver's Headquarters"] = L["Delver's Headquarters"],
					},
				},
				ShowOnDetection = {
					name = L["ShowOnDetection"],
					desc = L["ShowOnDetectionDescription"],
					type = "toggle",
					order = 8,
					width = "full",
					get = function(info)
						return VoidMark.db.profile.ShowOnDetection
					end,
					set = function(info, value)
						VoidMark.db.profile.ShowOnDetection = value
					end,
				},
				HideVoidMark = {
					name = L["HideVoidMark"],
					desc = L["HideVoidMarkDescription"],
					type = "toggle",
					order = 9,
					width = "full",
					get = function(info)
						return VoidMark.db.profile.HideVoidMark
					end,
					set = function(info, value)
						VoidMark.db.profile.HideVoidMark = value
						if VoidMark.db.profile.HideVoidMark and VoidMark:GetNearbyListSize() == 0 then
							VoidMark.MainWindow:Hide()
						end
					end,
				},
--[[				ShowOnlyPvPFlagged = {
					name = L["ShowOnlyPvPFlagged"],
					desc = L["ShowOnlyPvPFlaggedDescription"],
					type = "toggle",
					order = 4,
					width = "full",
					get = function(info)
						return VoidMark.db.profile.ShowOnlyPvPFlagged
					end,
					set = function(info, value)
						VoidMark.db.profile.ShowOnlyPvPFlagged = value
					end,
				},	]]--
				ShowKoSButton = {
					name = L["ShowKoSButton"],
					desc = L["ShowKoSButtonDescription"],
					type = "toggle",
					order = 10,
					width = "full",
					get = function(info)
						return VoidMark.db.profile.ShowKoSButton
					end,
					set = function(info, value)
						VoidMark.db.profile.ShowKoSButton = value
					end,
				},
			},
		},
		DisplayOptions = {
			name = L["DisplayOptions"],
			desc = L["DisplayOptions"],
			type = "group",
			order = 2,
			args = {
				intro = {
					name = L["DisplayOptionsDescription"],
					type = "description",
					order = 1,
					fontSize = "medium",
				},
				ShowNearbyList = {
					name = L["ShowNearbyList"],
					desc = L["ShowNearbyListDescription"],
					type = "toggle",
					order = 2,
					width = "full",
					get = function(info)
						return VoidMark.db.profile.ShowNearbyList
					end,
					set = function(info, value)
						VoidMark.db.profile.ShowNearbyList = value
					end,
				},
				PrioritiseKoS = {
					name = L["PrioritiseKoS"],
					desc = L["PrioritiseKoSDescription"],
					type = "toggle",
					order = 3,
					width = "full",
					get = function(info)
						return VoidMark.db.profile.PrioritiseKoS
					end,
					set = function(info, value)
						VoidMark.db.profile.PrioritiseKoS = value
					end,
				},
				HideWhenPVPUnflagged = {
					name = "Hide VoidMark when not PvP flagged",
					desc = "When enabled, the VoidMark window hides while your character is not PvP flagged. Off by default so VoidMark stays visible.",
					type = "toggle",
					order = 3.5,
					width = "full",
					get = function()
						return VoidMark.db.profile.DisableWhenPVPUnflagged
					end,
					set = function(info, value)
						VoidMark.db.profile.DisableWhenPVPUnflagged = value and true or false
						VoidMark:ZoneChangedEvent()
					end,
				},
				Alpha = {
					name = L["Alpha"],
					desc = L["AlphaDescription"],
					type = "range",
					order = 4,
--					width = "double",
					min = 0, max = 1, step = 0.01,
					isPercent = true,
					get = function()
						return VoidMark.db.profile.MainWindow.Alpha end,
					set = function(info, value)
						VoidMark.db.profile.MainWindow.Alpha = value
						VoidMark:UpdateMainWindow()

					end,
				},
				AlphaBG = {
					name = L["AlphaBG"],
					desc = L["AlphaBGDescription"],
					type = "range",
					order = 5,
--					width = "double",
					min = 0, max = 1, step = 0.01,
					isPercent = true,
					get = function()
						return VoidMark.db.profile.MainWindow.AlphaBG end,
					set = function(info, value)
						VoidMark.db.profile.MainWindow.AlphaBG = value
						VoidMark:UpdateMainWindow()
					end,
				},
				Lock = {
					name = L["LockVoidMark"],
					desc = L["LockVoidMarkDescription"],
					type = "toggle",
					order = 6,
					width = 1.6,
					get = function(info) 
						return VoidMark.db.profile.Locked
					end,
					set = function(info, value)
						VoidMark.db.profile.Locked = value
						VoidMark:LockWindows(value)
						VoidMark:RefreshCurrentList()
					end,
				},
				ClampToScreen = {
					name = L["ClampToScreen"],
					desc = L["ClampToScreenDescription"],
					type = "toggle",
					order = 7,
--					width = "double",
					get = function(info) 
						return VoidMark.db.profile.ClampToScreen
					end,
					set = function(info, value)
						VoidMark.db.profile.ClampToScreen = value
						VoidMark:ClampToScreen(value)
					end,
				},
				InvertVoidMark = {
					name = L["InvertVoidMark"],
					desc = L["InvertVoidMarkDescription"],
					type = "toggle",
					order = 8,
					get = function(info)
						return VoidMark.db.profile.InvertVoidMark
					end,
					set = function(info, value)
						VoidMark.db.profile.InvertVoidMark = value
					end,
				},
				[L["Reload"]] = {
					name = L["Reload"],
					desc = L["ReloadDescription"],
					type = 'execute',
					order = 9,
					width = .6,
					func = function()
						C_UI.Reload()
					end
				},
				ResizeVoidMark = {
					name = L["ResizeVoidMark"],
					desc = L["ResizeVoidMarkDescription"],
					type = "toggle",
					order = 10,
					width = "full",
					get = function(info)
						return VoidMark.db.profile.ResizeVoidMark
					end,
					set = function(info, value)
						VoidMark.db.profile.ResizeVoidMark = value
						if value then VoidMark:RefreshCurrentList() end
					end,
				},
				ResizeVoidMarkLimit = {  
					type = "range",
					order = 11,
					name = L["ResizeVoidMarkLimit"],
					desc = L["ResizeVoidMarkLimitDescription"],
					min = 1, max = 15, step = 1,
					get = function() return VoidMark.db.profile.ResizeVoidMarkLimit end,
					set = function(info, value)
						VoidMark.db.profile.ResizeVoidMarkLimit = value
						if value then 
							VoidMark:ResizeMainWindow()
							VoidMark:RefreshCurrentList() 
						end	
					end,
				},
				DisplayListData = {
					name = L["DisplayListData"],
					type = 'select',
					order = 12,
					values = {
						["1NameLevelClass"] = L["Name"].." / "..L["Level"].." / "..L["Class"],
						["2NameLevelGuild"] = L["Name"].." / "..L["Level"].." / "..L["Guild"],
						["3NameLevelOnly"] = L["Name"].." / "..L["Level"],
						["4NamePvPRank"] = L["Name"].." / "..L["Rank"],
						["5NameGuild"] = L["Name"].." / "..L["Guild"],
						["6NameOnly"] = L["Name"],
					},
					get = function()
						return VoidMark.db.profile.DisplayListData
					end,
					set = function(info, value)
						VoidMark.db.profile.DisplayListData = value
						VoidMark:RefreshCurrentList() 
					end,
				},
				SelectFont = {
					type = "select",
					order = 13,
					name = L["SelectFont"],
					desc = L["SelectFontDescription"],
					values = fonts,
					get = function()
						for info, value in next, fonts do
							if value == VoidMark.db.profile.Font then
								return info
							end
						end
					end,
					set = function(_, value)
						VoidMark.db.profile.Font = fonts[value]
						if value then
							VoidMark:UpdateBarTextures()
						end
					end,
				},
				RowHeight = {
					type = "range",
					order = 14,
					name = L["RowHeight"], 
					desc = L["RowHeightDescription"], 
					min = 8, max = 20, step = 1,
					get = function()
						return VoidMark.db.profile.MainWindow.RowHeight
					end,
					set = function(info, value)
						VoidMark.db.profile.MainWindow.RowHeight = value
						if value then
							VoidMark:BarsChanged()
						end
					end,
				},
				BarTexture = {
					type = "select",
					order = 15,
					name = L["Texture"],
					desc = L["TextureDescription"],	
					dialogControl = "LSM30_Statusbar",
					width = "double",
					values = SM:HashTable("statusbar"),
					get = function()
						return VoidMark.db.profile.BarTexture
					end,
					set = function(_, key)
						VoidMark.db.profile.BarTexture = key
						VoidMark:UpdateBarTextures()
					end,
				},
				DisplayTooltipNearVoidMarkWindow = {
					name = L["DisplayTooltipNearVoidMarkWindow"],
					desc = L["DisplayTooltipNearVoidMarkWindowDescription"],
					type = "toggle",
					order = 16,
					width = "full",
					get = function(info)
						return VoidMark.db.profile.DisplayTooltipNearVoidMarkWindow
					end,
					set = function(info, value)
						VoidMark.db.profile.DisplayTooltipNearVoidMarkWindow = value
					end,
				},	
				SelectTooltipAnchor = {
					type = "select",
					order = 17,
					name = L["SelectTooltipAnchor"],
					desc = L["SelectTooltipAnchorDescription"],
					values = { 
						["ANCHOR_CURSOR"] = L["ANCHOR_CURSOR"],
						["ANCHOR_TOP"] = L["ANCHOR_TOP"],
						["ANCHOR_BOTTOM"] = L["ANCHOR_BOTTOM"],
						["ANCHOR_LEFT"] = L["ANCHOR_LEFT"],
						["ANCHOR_RIGHT"] = L["ANCHOR_RIGHT"], 
					},
					get = function()
						return VoidMark.db.profile.TooltipAnchor
					end,
					set = function(info, value)
						VoidMark.db.profile.TooltipAnchor = value
					end,
				},
				DisplayWinLossStatistics = {
					name = L["TooltipDisplayWinLoss"],
					desc = L["TooltipDisplayWinLossDescription"],
					type = "toggle",
					order = 18,
					width = "full",
					get = function(info)
						return VoidMark.db.profile.DisplayWinLossStatistics
					end,
					set = function(info, value)
						VoidMark.db.profile.DisplayWinLossStatistics = value
					end,
				},
				DisplayKOSReason = {
					name = L["TooltipDisplayKOSReason"],
					desc = L["TooltipDisplayKOSReasonDescription"],
					type = "toggle",
					order = 19,
					width = "full",
					get = function(info)
						return VoidMark.db.profile.DisplayKOSReason
					end,
					set = function(info, value)
						VoidMark.db.profile.DisplayKOSReason = value
					end,
				},
				DisplayLastSeen = {
					name = L["TooltipDisplayLastSeen"],
					desc = L["TooltipDisplayLastSeenDescription"],
					type = "toggle",
					order = 20,
					width = "full",
					get = function(info)
						return VoidMark.db.profile.DisplayLastSeen
					end,
					set = function(info, value)
						VoidMark.db.profile.DisplayLastSeen = value
					end,
				},
			},
		},
		AlertOptions = {
			name = L["AlertOptions"],
			desc = L["AlertOptions"],
			type = "group",
			order = 3,
			args = {
				intro = {
					name = L["AlertOptionsDescription"],
					type = "description",
					order = 1,
					fontSize = "medium",
				},
				EnableSound = {
					name = L["EnableSound"],
					desc = L["EnableSoundDescription"],
					type = "toggle",
					order = 2,
					width = "full",
					get = function(info)
						return VoidMark.db.profile.EnableSound
					end,
					set = function(info, value)
						VoidMark.db.profile.EnableSound = value
					end,
				},
				SoundChannel = {
					name = L["SoundChannel"],
					type = 'select',
					order = 3,
					values = {
						["Master"] = L["Master"],
						["SFX"] = L["SFX"],
						["Music"] = L["Music"],
						["Ambience"] = L["Ambience"],
					},					
					get = function()
						return VoidMark.db.profile.SoundChannel
					end,
					set = function(info, value)
						VoidMark.db.profile.SoundChannel = value 
					end,
				},
				OnlySoundKoS = {
					name = L["OnlySoundKoS"],
					desc = L["OnlySoundKoSDescription"],
					type = "toggle",
					order = 4,
					width = "full",
					get = function(info)
						return VoidMark.db.profile.OnlySoundKoS
					end,
					set = function(info, value)
						VoidMark.db.profile.OnlySoundKoS = value
					end,
				},
				StopAlertsOnTaxi = {
					name = L["StopAlertsOnTaxi"],
					desc = L["StopAlertsOnTaxiDescription"],
					type = "toggle",
					order = 5,
					width = "full",
					get = function(info)
						return VoidMark.db.profile.StopAlertsOnTaxi
					end,
					set = function(info, value)
						VoidMark.db.profile.StopAlertsOnTaxi = value
					end,
				},
				Announce = {
					name = L["Announce"],
					type = "group",
					order = 6,
					inline = true,
					args = {
						None = {
							name = L["None"],
							desc = L["NoneDescription"],
							type = "toggle",
							order = 1,
							get = function(info)
								return VoidMark.db.profile.Announce == "None"
							end,
							set = function(info, value)
								VoidMark.db.profile.Announce = "None"
							end,
						},
						Self = {
							name = L["Self"],
							desc = L["SelfDescription"],
							type = "toggle",
							order = 2,
							get = function(info)
								return VoidMark.db.profile.Announce == "Self"
							end,
							set = function(info, value)
								VoidMark.db.profile.Announce = "Self"
							end,
						},
						Party = {
							name = L["Party"],
							desc = L["PartyDescription"],
							type = "toggle",
							order = 3,
							get = function(info)
								return VoidMark.db.profile.Announce == "Party"
							end,
							set = function(info, value)
								VoidMark.db.profile.Announce = "Party"
							end,
						},
						Guild = {
							name = L["Guild"],
							desc = L["GuildDescription"],
							type = "toggle",
							order = 4,
							get = function(info)
								return VoidMark.db.profile.Announce == "Guild"
							end,
							set = function(info, value)
								VoidMark.db.profile.Announce = "Guild"
							end,
						},
						Raid = {
							name = L["Raid"],
							desc = L["RaidDescription"],
							type = "toggle",
							order = 5,
							get = function(info)
								return VoidMark.db.profile.Announce == "Raid"
							end,
							set = function(info, value)
								VoidMark.db.profile.Announce = "Raid"
							end,
						},
					},
				},
				OnlyAnnounceKoS = {
					name = L["OnlyAnnounceKoS"],
					desc = L["OnlyAnnounceKoSDescription"],
					type = "toggle",
					order = 7,
					width = "full",
					get = function(info)
						return VoidMark.db.profile.OnlyAnnounceKoS
					end,
					set = function(info, value)
						VoidMark.db.profile.OnlyAnnounceKoS = value
					end,
				},
				DisplayWarnings = {
					name = L["DisplayWarnings"],
					type = 'select',
					order = 8,
					values = {
						["Default"] = L["Default"],
						["ErrorFrame"] = L["ErrorFrame"],
						["Moveable"] = L["Moveable"],
					},
					get = function()
						return VoidMark.db.profile.DisplayWarnings
					end,
					set = function(info, value)
						VoidMark.db.profile.DisplayWarnings = value
						VoidMark:UpdateAlertWindow()
					end,
				},
				WarnOnStealth = {
					name = L["WarnOnStealth"],
					desc = L["WarnOnStealthDescription"],
					type = "toggle",
					order = 9,
					width = "full",
					get = function(info)
						return VoidMark.db.profile.WarnOnStealth
					end,
					set = function(info, value)
						VoidMark.db.profile.WarnOnStealth = value
					end,
				},
				WarnOnKOS = {
					name = L["WarnOnKOS"],
					desc = L["WarnOnKOSDescription"],
					type = "toggle",
					order = 10,
					width = "full",
					get = function(info)
						return VoidMark.db.profile.WarnOnKOS
					end,
					set = function(info, value)
						VoidMark.db.profile.WarnOnKOS = value
					end,
				},
				WarnOnKOSGuild = {
					name = L["WarnOnKOSGuild"],
					desc = L["WarnOnKOSGuildDescription"],
					type = "toggle",
					order = 11,
					width = "full",
					get = function(info)
						return VoidMark.db.profile.WarnOnKOSGuild
					end,
					set = function(info, value)
						VoidMark.db.profile.WarnOnKOSGuild = value
					end,
				},
				WarnOnRace = {
					name = L["WarnOnRace"],
					desc = L["WarnOnRaceDescription"],
					type = "toggle",
					order = 12,
					width = "full",
					get = function(info)
						return VoidMark.db.profile.WarnOnRace
					end,
					set = function(info, value)
						VoidMark.db.profile.WarnOnRace = value
					end,
				},
				SelectWarnRace = {
					type = "select",
					order = 13,
					name = L["SelectWarnRace"],
					desc = L["SelectWarnRaceDescription"],
					get = function()
						return VoidMark.db.profile.SelectWarnRace
					end,
					set = function(info, value)
						VoidMark.db.profile.SelectWarnRace = value
					end,
					values = function()
						local raceOptions = {}
						local races = {
							Alliance = {
								["None"] = L["None"],
								["Human"] = L["Human"],
								["Dwarf"] = L["Dwarf"],
								["Night Elf"] = L["Night Elf"],
								["Gnome"] = L["Gnome"],
--								["Draenei"] = L["Draenei"],
--								["Worgen"] = L["Worgen"],
--								["Pandaren"] = L["Pandaren"],
--								["Lightforged Draenei"] = L["Lightforged Draenei"],
--								["Void Elf"] = L["Void Elf"],
--								["Dark Iron Dwarf"] = L["Dark Iron Dwarf"],
--								["Kul Tiran"] = L["Kul Tiran"],
--								["Mechagnome"] = L["Mechagnome"],
--								["Dracthyr"] = L["Dracthyr"],
--								["Earthen"] = L["Earthen"],
							},
							Horde = {
								["None"] = L["None"],
								["Orc"] = L["Orc"],
								["Tauren"] = L["Tauren"],
								["Troll"] = L["Troll"],
								["Undead"] = L["Undead"],
--								["Blood Elf"] = L["Blood Elf"],
--								["Goblin"] = L["Goblin"],
--								["Pandaren"] = L["Pandaren"],
--								["Highmountain Tauren"] = L["Highmountain Tauren"],
--								["Nightborne"] = L["Nightborne"],
--								["Mag'har Orc"] = L["Mag'har Orc"],
--								["Zandalari Troll"] = L["Zandalari Troll"],
--								["Vulpera"] = L["Vulpera"],
--								["Dracthyr"] = L["Dracthyr"],
--								["Earthen"] = L["Earthen"],
							},
						}
						if VoidMark.EnemyFactionName == "Alliance" then
							raceOptions = races.Alliance
						end	
						if VoidMark.EnemyFactionName == "Horde" then
							raceOptions = races.Horde
						end	
						return raceOptions
					end,
				},
				WarnRaceNote = {
					order = 14,
					type = "description",
					name = L["WarnRaceNote"],
				},
			},
		},
		TrackingOptions = {
			name = "Tracking",
			desc = "VoidMark tracking behavior",
			type = "group",
			order = 5,
			args = {
				intro = {
					name = "|cffb86cffPermanent history|r\nVoidMark never age-purges player records, KOS entries, or win/loss history. Map/minimap tracking and old VoidMark-user data sharing are disabled in this build.",
					type = "description",
					order = 1,
					fontSize = "medium",
				},
				IgnoreBattlegroundStats = {
					name = "Ignore battleground PvP for stats",
					desc = "When enabled, battleground kills and deaths are not written to VoidMark kill/death history, W/L records, session K/D, streaks, or fight records. Enemy detection still works in battlegrounds.",
					type = "toggle",
					order = 2,
					width = "full",
					get = function()
						return VoidMark.db.profile.IgnoreBattlegroundStats
					end,
					set = function(info, value)
						VoidMark.db.profile.IgnoreBattlegroundStats = value and true or false
					end,
				},
				RemoveUndetected = {
					name = "Nearby list timeout",
					desc = "How long an enemy stays in the live Nearby list after activity stops. This only clears the live list; it never deletes the player's saved history.",
					type = "select",
					order = 3,
					values = {
						OneMinute = "1 minute",
						TwoMinutes = "2 minutes",
						FiveMinutes = "5 minutes",
						TenMinutes = "10 minutes",
						FifteenMinutes = "15 minutes",
						Never = "Never",
					},
					get = function()
						return VoidMark.db.profile.RemoveUndetected or "OneMinute"
					end,
					set = function(info, value)
						VoidMark.db.profile.RemoveUndetected = value
						VoidMark:UpdateTimeoutSettings()
					end,
				},
				permanent = {
					name = "Saved enemy history: |cff66ff66PERMANENT|r\nKOS sharing between your own characters: |cff66ff66ON|r\nMap/minimap enemy overlays: |cffff6666OFF|r\nOther VoidMark/VoidMark user data sharing: |cffff6666OFF|r",
					type = "description",
					order = 4,
				},
			},
		},
	},
}

VoidMark.optionsSlash = {
	name = "VoidMark Commands",
	order = -3,
	type = "group",
	args = {
		intro = {
			name = "VoidMark commands. Use /vm or /voidmark.",
			type = "description",
			order = 1,
			cmdHidden = true,
		},
		show = {
			name = L["Show"],
			desc = L["ShowDescription"],
			type = 'execute',
			order = 2,
			func = function()
				VoidMark:EnableVoidMark(true, true)
			end,
			dialogHidden = true
		},
		hide = {
			name = L["Hide"],
			desc = L["HideDescription"],
			type = 'execute',
			order = 3,
			func = function()
				VoidMark:EnableVoidMark(false, true)
			end,
			dialogHidden = true
		},		
		reset = {
			name = L["Reset"],
			desc = "Resets the position of the VoidMark windows.",
			type = 'execute',
			order = 4,
			func = function()
				VoidMark:ResetPositions()
			end,
			dialogHidden = true
		},
		clear = {
			name = L["ClearSlash"],
			desc = L["ClearSlashDescription"],
			type = 'execute',
			order = 5,
			func = function()
				VoidMark:ClearList()
			end,
			dialogHidden = true
		},			
		config = {
			name = L["Config"],
			desc = "Open the Interface AddOns configuration window for VoidMark.",
			type = 'execute',
			order = 6,
			func = function()
				VoidMark:ShowConfig()
			end,
			dialogHidden = true
		},
		kos = {
			name = L["KOS"],
			desc = L["KOSDescription"],
			type = 'input',
			order = 7,
			pattern = ".",	-- Changed so names with special characters can be added
			set = function(info, value)
				if VoidMark_IgnoreList[value] or strmatch(value, "[%s%d]+") then
					DEFAULT_CHAT_FRAME:AddMessage(value .. " - " .. L["InvalidInput"])
				else
					VoidMark:ToggleKOSPlayer(not VoidMarkPerCharDB.KOSData[value], value)
				end	
			end,
			dialogHidden = true
		}, 
		ignore = {
			name = L["Ignore"],
			desc = L["IgnoreDescription"],
			type = 'input',
			order = 8,
			pattern = ".",
			set = function(info, value)
				if VoidMark_IgnoreList[value] or strmatch(value, "[%s%d]+") then
					DEFAULT_CHAT_FRAME:AddMessage(value .. " - " .. L["InvalidInput"])
				else
					VoidMark:ToggleIgnorePlayer(not VoidMarkPerCharDB.IgnoreData[value], value)
				end
			end,
			dialogHidden = true
		},
		stats = {
			name = L["Statistics"],
			desc = L["StatsDescription"],
			type = 'execute',
			order = 9,
			func = function()
				VoidMarkStats:Toggle()
			end,
			dialogHidden = true
		},
		test = {
			name = L["Test"],
			desc = L["TestDescription"],
			type = 'execute',
			order = 10,
			func = function()
				VoidMark:AlertStealthPlayer("Bazzalan")
			end
		},
--[[		sanc = {
			name = L["Sanctuary"],
			desc = L["SanctuaryDescription"],
			type = 'execute',
			order = 11,
			func = function()
				VoidMark.db.profile.EnabledInSanctuaries = not VoidMark.db.profile.EnabledInSanctuaries
				VoidMark:ZoneChangedEvent()
	--			VoidMark:UpdateMainWindow()
	--			VoidMark:EnableVoidMark(false, true)
			end,
			dialogHidden = true
		}, ]]--
	},
}

local Default_Profile = {
	profile = {
		Colors = {
			["Window"] = {
				["Title"] = { r = 1, g = 1, b = 1, a = 1 },
				["Background"]= { r = 24/255, g = 24/255, b = 24/255, a = 1 },
				["Title Text"] = { r = 1, g = 1, b = 1, a = 1 },
			},
			["Other Windows"] = {
				["Title"] = { r = 1, g = 0, b = 0, a = 1 },
				["Background"]= { r = 24/255, g = 24/255, b = 24/255, a = 1 },
				["Title Text"] = { r = 1, g = 1, b = 1, a = 1 },
			},
			["Bar"] = {
				["Bar Text"] = { r = 1, g = 1, b = 1 },
			},
			["Warning"] = {
				["Warning Text"] = { r = 1, g = 1, b = 1 },
			},
			["Tooltip"] = {
				["Title Text"] = { r = 0.8, g = 0.3, b = 0.22 },
				["Details Text"] = { r = 1, g = 1, b = 1 },
				["Location Text"] = { r = 1, g = 0.82, b = 0 },
				["Reason Text"] = { r = 1, g = 0, b = 0 },
			},
			["Alert"] = {
				["Background"]= { r = 0, g = 0, b = 0, a = 0.4 },
				["Icon"] = { r = 1, g = 1, b = 1, a = 0.5 },
				["KOS Border"] = { r = 1, g = 0, b = 0, a = 0.4 },
				["KOS Text"] = { r = 1, g = 0, b = 0 },
				["KOS Guild Border"] = { r = 1, g = 0.82, b = 0, a = 0.4 },
				["KOS Guild Text"] = { r = 1, g = 0.82, b = 0 },
				["Stealth Border"] = { r = 0.6, g = 0.2, b = 1, a = 0.4 },
				["Stealth Text"] = { r = 0.6, g = 0.2, b = 1 },
				["Away Border"] = { r = 0, g = 1, b = 0, a = 0.4 },
				["Away Text"] = { r = 0, g = 1, b = 0 },
				["Location Text"] = { r = 1, g = 0.82, b = 0 },
				["Name Text"] = { r = 1, g = 1, b = 1 },
			},
			["Class"] = {
				["HUNTER"] = { r = 0.67, g = 0.83, b = 0.45, a = 0.6 },
				["WARLOCK"] = { r = 0.53, g = 0.53, b = 0.93, a = 0.6 },
				["PRIEST"] = { r = 1.00, g = 1.00, b = 1.00, a = 0.6 },
				["PALADIN"] = { r = 0.96, g = 0.55, b = 0.73, a = 0.6 },
				["MAGE"] = { r = 0.25, g = 0.78, b = 0.92, a = 0.6 },
				["ROGUE"] = { r = 1.00, g = 0.96, b = 0.41, a = 0.6 },
				["DRUID"] = { r = 1.00, g = 0.49, b = 0.04, a = 0.6 },
				["SHAMAN"] = { r = 0.00, g = 0.44, b = 0.87, a = 0.6 },
				["WARRIOR"] = { r = 0.78, g = 0.61, b = 0.43, a = 0.6 },
--				["DEATHKNIGHT"] = { r = 0.77, g = 0.12, b = 0.23, a = 0.6 },
--				["MONK"] = { r = 0.00, g = 1.00, b = 0.60, a = 0.6 },
--				["DEMONHUNTER"] = { r = 0.64, g = 0.19, b = 0.79, a = 0.6 },
--				["EVOKER"] = { r = 0.20, g = 0.58, b = 0.50, a = 0.6 },
				["PET"] = { r = 0.09, g = 0.61, b = 0.55, a = 0.6 },
				["MOB"] = { r = 0.58, g = 0.24, b = 0.63, a = 0.6 },
				["UNKNOWN"] = { r = 0.1, g = 0.1, b = 0.1, a = 0.6 },
				["HOSTILE"] = { r = 0.7, g = 0.1, b = 0.1, a = 0.6 },
				["UNGROUPED"] = { r = 0.63, g = 0.58, b = 0.24, a = 0.6 },
			},
		},
		MainWindow={
			Alpha=1,
			AlphaBG=1,
			Buttons={
				ClearButton=true,
				LeftButton=true,
				RightButton=true,
			},
			RowHeight=14,
			RowSpacing=2,
			TextHeight=12,
			AutoHide=true,
			BarText={
				RankNum = true,
				PerSec = true,
				Percent = true,
				NumFormat = 1,
			},
			Position={
				x = 4,
				y = 740,
				w = 160,
				h = 34,
			},
		},
		AlertWindow={
			Position={
--				x = 0,
--				y = -140,
				x = 750,
				y = 750,
			},
			NameSize=14,
			LocationSize=10,
		},
		BarTexture="Flat",
		MainWindowVis=true,
		CurrentList=1,
		Locked=false,
		ClampToScreen=true,
		Font="Friz Quadrata TT",
		Scaling=1,
		Enabled=true,
		EnabledInBattlegrounds=true,
		EnabledInSanctuaries=false,
		EnabledInArenas=true,
		EnabledInWintergrasp=true,
		DisableWhenPVPUnflagged=false,
		IgnoreBattlegroundStats=true,
		MinimapDetection=false,
		MinimapDetails=false,
		DisplayOnMap=false,
		SwitchToZone=false,
		MapDisplayLimit="None",
		DisplayTooltipNearVoidMarkWindow=false,
		TooltipAnchor="ANCHOR_CURSOR",
		DisplayWinLossStatistics=true,
		DisplayKOSReason=true,
		DisplayLastSeen=true,
		DisplayListData="1NameLevelClass",
		ShowOnDetection=true,
		HideVoidMark=false,
--		ShowOnlyPvPFlagged=false,
		ShowKoSButton=false,
		InvertVoidMark=false,
		ResizeVoidMark=true,
		ResizeVoidMarkLimit=15,
		SoundChannel="SFX",
		Announce="None",
		OnlyAnnounceKoS=false,
		WarnOnStealth=true,
		WarnOnKOS=true,
		WarnOnKOSGuild=false,
		WarnOnRace=false,
		SelectWarnRace="None",
		DisplayWarnings="Default",
		EnableSound=true,
		OnlySoundKoS=false, 
		StopAlertsOnTaxi=true,
		RemoveUndetected="OneMinute",
		ShowNearbyList=true,
		PrioritiseKoS=true,
		PurgeData="Never",
		PurgeKoS=false,
		PurgeWinLossData=false,
		ShareData=false,
		UseData=false,
		ShareKOSBetweenCharacters=true,
		AppendUnitNameCheck=false,
		AppendUnitKoSCheck=false,
		FilteredZones = {
			["Booty Bay"] = false,
			["Gadgetzan"] = false,
			["Ratchet"] = false,
			["Everlook"] = false,
			["The Salty Sailor Tavern"] = false,
			["Cenarion Hold"] = false,
--			["Shattrath City"] = false,
--			["Area 52"] = false,
--			["Dalaran"] = false,
--			["Bogpaddle"] = false,
--			["The Vindicaar"] = false,
--			["Krasus' Landing"] = false,
--			["The Violet Gate"] = false,
--			["Magni's Encampment"] = false,
--			["Chamber of Heart"] = false,
--			["Hall of Ancient Paths"] = false,
--			["Sanctum of the Sages"] = false,
--			["Rustbolt"] = false,
--			["Oribos"] = false,
--			["Valdrakken"] = false,
--			["The Roasted Ram"] = false,
--			["Dornogal"] = false,
--			["Stonelight Rest"] = false,
--			["Delver's Headquarters"] = false,
		},
	},
}

SM:Register("statusbar", "Flat", [[Interface\AddOns\VoidMarkForever\Textures\bar-flat.tga]])

function VoidMark:CheckDatabase()

	--------------------------------------------------
	-- TALIAA SPY SHARED DATABASE
	-- Shared across characters on the same faction.
	-- Horde and Alliance remain separate.
	--------------------------------------------------

	VoidMarkDB.TaliaaShared = VoidMarkDB.TaliaaShared or {}

	local cluster = "Forever"

	VoidMarkDB.TaliaaShared[cluster] =
		VoidMarkDB.TaliaaShared[cluster] or {}

	VoidMarkDB.TaliaaShared[cluster][VoidMark.FactionName] =
		VoidMarkDB.TaliaaShared[cluster][VoidMark.FactionName] or {}

	-- Keep the rest of VoidMark unchanged by redirecting
	-- its normal per-character table to our shared table.
	VoidMarkPerCharDB =
		VoidMarkDB.TaliaaShared[cluster][VoidMark.FactionName]

	VoidMarkPerCharDB.version = VoidMark.DatabaseVersion

	if not VoidMarkPerCharDB.PlayerData then
		VoidMarkPerCharDB.PlayerData = {}
	end

	if not VoidMarkPerCharDB.IgnoreData then
		VoidMarkPerCharDB.IgnoreData = {}
	end

	if not VoidMarkPerCharDB.KOSData then
		VoidMarkPerCharDB.KOSData = {}
	end

	-- Retired list storage remains account-wide on this faction, matching the shared
	-- TaliaaVoidMark player/KOS database. Cross-account sync is handled in a later stage.
	if not VoidMarkPerCharDB.HuntData then
		VoidMarkPerCharDB.HuntData = {}
	end

	--------------------------------------------------
	-- END TALIAA SPY SHARED DATABASE
	--------------------------------------------------
	if VoidMarkDB.kosData == nil then VoidMarkDB.kosData = {} end
	if VoidMarkDB.kosData[VoidMark.RealmName] == nil then VoidMarkDB.kosData[VoidMark.RealmName] = {} end
	if VoidMarkDB.kosData[VoidMark.RealmName][VoidMark.FactionName] == nil then VoidMarkDB.kosData[VoidMark.RealmName][VoidMark.FactionName] = {} end
	if VoidMarkDB.kosData[VoidMark.RealmName][VoidMark.FactionName][VoidMark.CharacterName] == nil then VoidMarkDB.kosData[VoidMark.RealmName][VoidMark.FactionName][VoidMark.CharacterName] = {} end
	if VoidMarkDB.removeKOSData == nil then VoidMarkDB.removeKOSData = {} end
	if VoidMarkDB.removeKOSData[VoidMark.RealmName] == nil then VoidMarkDB.removeKOSData[VoidMark.RealmName] = {} end
	if VoidMarkDB.removeKOSData[VoidMark.RealmName][VoidMark.FactionName] == nil then VoidMarkDB.removeKOSData[VoidMark.RealmName][VoidMark.FactionName] = {} end
--[[	if VoidMark.db.profile == nil then VoidMark.db.profile = Default_Profile.profile end
	if VoidMark.db.profile.Colors == nil then VoidMark.db.profile.Colors = Default_Profile.profile.Colors end
	if VoidMark.db.profile.Colors["Window"] == nil then VoidMark.db.profile.Colors["Window"] = Default_Profile.profile.Colors["Window"] end
	if VoidMark.db.profile.Colors["Window"]["Title"] == nil then VoidMark.db.profile.Colors["Window"]["Title"] = Default_Profile.profile.Colors["Window"]["Title"] end
	if VoidMark.db.profile.Colors["Window"]["Background"] == nil then VoidMark.db.profile.Colors["Window"]["Background"] = Default_Profile.profile.Colors["Window"]["Background"] end
	if VoidMark.db.profile.Colors["Window"]["Title Text"] == nil then VoidMark.db.profile.Colors["Window"]["Title Text"] = Default_Profile.profile.Colors["Window"]["Title Text"] end
	if VoidMark.db.profile.Colors["Other Windows"] == nil then VoidMark.db.profile.Colors["Other Windows"] = Default_Profile.profile.Colors["Other Windows"] end
	if VoidMark.db.profile.Colors["Other Windows"]["Title"] == nil then VoidMark.db.profile.Colors["Other Windows"]["Title"] = Default_Profile.profile.Colors["Other Windows"]["Title"] end
	if VoidMark.db.profile.Colors["Other Windows"]["Background"] == nil then VoidMark.db.profile.Colors["Other Windows"]["Background"] = Default_Profile.profile.Colors["Other Windows"]["Background"] end
	if VoidMark.db.profile.Colors["Other Windows"]["Title Text"] == nil then VoidMark.db.profile.Colors["Other Windows"]["Title Text"] = Default_Profile.profile.Colors["Other Windows"]["Title Text"] end
	if VoidMark.db.profile.Colors["Bar"] == nil then VoidMark.db.profile.Colors["Bar"] = Default_Profile.profile.Colors["Bar"] end
	if VoidMark.db.profile.Colors["Bar"]["Bar Text"] == nil then VoidMark.db.profile.Colors["Bar"]["Bar Text"] = Default_Profile.profile.Colors["Bar"]["Bar Text"] end
	if VoidMark.db.profile.Colors["Warning"] == nil then VoidMark.db.profile.Colors["Warning"] = Default_Profile.profile.Colors["Warning"] end
	if VoidMark.db.profile.Colors["Warning"]["Warning Text"] == nil then VoidMark.db.profile.Colors["Warning"]["Warning Text"] = Default_Profile.profile.Colors["Warning"]["Warning Text"] end
	if VoidMark.db.profile.Colors["Tooltip"] == nil then VoidMark.db.profile.Colors["Tooltip"] = Default_Profile.profile.Colors["Tooltip"] end
	if VoidMark.db.profile.Colors["Tooltip"]["Title Text"] == nil then VoidMark.db.profile.Colors["Tooltip"]["Title Text"] = Default_Profile.profile.Colors["Tooltip"]["Title Text"] end
	if VoidMark.db.profile.Colors["Tooltip"]["Details Text"] == nil then VoidMark.db.profile.Colors["Tooltip"]["Details Text"] = Default_Profile.profile.Colors["Tooltip"]["Details Text"] end
	if VoidMark.db.profile.Colors["Tooltip"]["Location Text"] == nil then VoidMark.db.profile.Colors["Tooltip"]["Location Text"] = Default_Profile.profile.Colors["Tooltip"]["Location Text"] end
	if VoidMark.db.profile.Colors["Tooltip"]["Reason Text"] == nil then VoidMark.db.profile.Colors["Tooltip"]["Reason Text"] = Default_Profile.profile.Colors["Tooltip"]["Reason Text"] end
	if VoidMark.db.profile.Colors["Alert"] == nil then VoidMark.db.profile.Colors["Alert"] = Default_Profile.profile.Colors["Alert"] end
	if VoidMark.db.profile.Colors["Alert"]["Background"] == nil then VoidMark.db.profile.Colors["Alert"]["Background"] = Default_Profile.profile.Colors["Alert"]["Background"] end
	if VoidMark.db.profile.Colors["Alert"]["Icon"] == nil then VoidMark.db.profile.Colors["Alert"]["Icon"] = Default_Profile.profile.Colors["Alert"]["Icon"] end
	if VoidMark.db.profile.Colors["Alert"]["KOS Border"] == nil then VoidMark.db.profile.Colors["Alert"]["KOS Border"] = Default_Profile.profile.Colors["Alert"]["KOS Border"] end
	if VoidMark.db.profile.Colors["Alert"]["KOS Text"] == nil then VoidMark.db.profile.Colors["Alert"]["KOS Text"] = Default_Profile.profile.Colors["Alert"]["KOS Text"] end
	if VoidMark.db.profile.Colors["Alert"]["KOS Guild Border"] == nil then VoidMark.db.profile.Colors["Alert"]["KOS Guild Border"] = Default_Profile.profile.Colors["Alert"]["KOS Guild Border"] end
	if VoidMark.db.profile.Colors["Alert"]["KOS Guild Text"] == nil then VoidMark.db.profile.Colors["Alert"]["KOS Guild Text"] = Default_Profile.profile.Colors["Alert"]["KOS Guild Text"] end
	if VoidMark.db.profile.Colors["Alert"]["Stealth Border"] == nil then VoidMark.db.profile.Colors["Alert"]["Stealth Border"] = Default_Profile.profile.Colors["Alert"]["Stealth Border"] end
	if VoidMark.db.profile.Colors["Alert"]["Stealth Text"] == nil then VoidMark.db.profile.Colors["Alert"]["Stealth Text"] = Default_Profile.profile.Colors["Alert"]["Stealth Text"] end
	if VoidMark.db.profile.Colors["Alert"]["Away Border"] == nil then VoidMark.db.profile.Colors["Alert"]["Away Border"] = Default_Profile.profile.Colors["Alert"]["Away Border"] end
	if VoidMark.db.profile.Colors["Alert"]["Away Text"] == nil then VoidMark.db.profile.Colors["Alert"]["Away Text"] = Default_Profile.profile.Colors["Alert"]["Away Text"] end
	if VoidMark.db.profile.Colors["Alert"]["Location Text"] == nil then VoidMark.db.profile.Colors["Alert"]["Location Text"] = Default_Profile.profile.Colors["Alert"]["Location Text"] end
	if VoidMark.db.profile.Colors["Alert"]["Name Text"] == nil then VoidMark.db.profile.Colors["Alert"]["Name Text"] = Default_Profile.profile.Colors["Alert"]["Name Text"] end
	if VoidMark.db.profile.Colors["Class"] == nil then VoidMark.db.profile.Colors["Class"] = Default_Profile.profile.Colors["Class"] end
	if VoidMark.db.profile.Colors["Class"]["HUNTER"] == nil then VoidMark.db.profile.Colors["Class"]["HUNTER"] = Default_Profile.profile.Colors["Class"]["HUNTER"] end
	if VoidMark.db.profile.Colors["Class"]["WARLOCK"] == nil then VoidMark.db.profile.Colors["Class"]["WARLOCK"] = Default_Profile.profile.Colors["Class"]["WARLOCK"] end
	if VoidMark.db.profile.Colors["Class"]["PRIEST"] == nil then VoidMark.db.profile.Colors["Class"]["PRIEST"] = Default_Profile.profile.Colors["Class"]["PRIEST"] end
	if VoidMark.db.profile.Colors["Class"]["PALADIN"] == nil then VoidMark.db.profile.Colors["Class"]["PALADIN"] = Default_Profile.profile.Colors["Class"]["PALADIN"] end
	if VoidMark.db.profile.Colors["Class"]["MAGE"] == nil then VoidMark.db.profile.Colors["Class"]["MAGE"] = Default_Profile.profile.Colors["Class"]["MAGE"] end
	if VoidMark.db.profile.Colors["Class"]["ROGUE"] == nil then VoidMark.db.profile.Colors["Class"]["ROGUE"] = Default_Profile.profile.Colors["Class"]["ROGUE"] end
	if VoidMark.db.profile.Colors["Class"]["DRUID"] == nil then VoidMark.db.profile.Colors["Class"]["DRUID"] = Default_Profile.profile.Colors["Class"]["DRUID"] end
	if VoidMark.db.profile.Colors["Class"]["SHAMAN"] == nil then VoidMark.db.profile.Colors["Class"]["SHAMAN"] = Default_Profile.profile.Colors["Class"]["SHAMAN"] end
	if VoidMark.db.profile.Colors["Class"]["WARRIOR"] == nil then VoidMark.db.profile.Colors["Class"]["WARRIOR"] = Default_Profile.profile.Colors["Class"]["WARRIOR"] end
--	if VoidMark.db.profile.Colors["Class"]["DEATHKNIGHT"] == nil then VoidMark.db.profile.Colors["Class"]["DEATHKNIGHT"] = Default_Profile.profile.Colors["Class"]["DEATHKNIGHT"] end
--	if VoidMark.db.profile.Colors["Class"]["MONK"] == nil then VoidMark.db.profile.Colors["Class"]["MONK"] = Default_Profile.profile.Colors["Class"]["MONK"] end
--	if VoidMark.db.profile.Colors["Class"]["DEMONHUNTER"] == nil then VoidMark.db.profile.Colors["Class"]["DEMONHUNTER"] = Default_Profile.profile.Colors["Class"]["DEMONHUNTER"] end	
	if VoidMark.db.profile.Colors["Class"]["PET"] == nil then VoidMark.db.profile.Colors["Class"]["PET"] = Default_Profile.profile.Colors["Class"]["PET"] end
	if VoidMark.db.profile.Colors["Class"]["MOB"] == nil then VoidMark.db.profile.Colors["Class"]["MOB"] = Default_Profile.profile.Colors["Class"]["MOB"] end
	if VoidMark.db.profile.Colors["Class"]["UNKNOWN"] == nil then VoidMark.db.profile.Colors["Class"]["UNKNOWN"] = Default_Profile.profile.Colors["Class"]["UNKNOWN"] end
	if VoidMark.db.profile.Colors["Class"]["HOSTILE"] == nil then VoidMark.db.profile.Colors["Class"]["HOSTILE"] = Default_Profile.profile.Colors["Class"]["HOSTILE"] end
	if VoidMark.db.profile.Colors["Class"]["UNGROUPED"] == nil then VoidMark.db.profile.Colors["Class"]["UNGROUPED"] = Default_Profile.profile.Colors["Class"]["UNGROUPED"] end
	if VoidMark.db.profile.MainWindow == nil then VoidMark.db.profile.MainWindow = Default_Profile.profile.MainWindow end
	if VoidMark.db.profile.MainWindow.Buttons == nil then VoidMark.db.profile.MainWindow.Buttons = Default_Profile.profile.MainWindow.Buttons end
	if VoidMark.db.profile.MainWindow.Buttons.ClearButton == nil then VoidMark.db.profile.MainWindow.Buttons.ClearButton = Default_Profile.profile.MainWindow.Buttons.ClearButton end
	if VoidMark.db.profile.MainWindow.Buttons.LeftButton == nil then VoidMark.db.profile.MainWindow.Buttons.LeftButton = Default_Profile.profile.MainWindow.Buttons.LeftButton end
	if VoidMark.db.profile.MainWindow.Buttons.RightButton == nil then VoidMark.db.profile.MainWindow.Buttons.RightButton = Default_Profile.profile.MainWindow.Buttons.RightButton end
	if VoidMark.db.profile.MainWindow.RowHeight == nil then VoidMark.db.profile.MainWindow.RowHeight = Default_Profile.profile.MainWindow.RowHeight end
	if VoidMark.db.profile.MainWindow.RowSpacing == nil then VoidMark.db.profile.MainWindow.RowSpacing = Default_Profile.profile.MainWindow.RowSpacing end
	if VoidMark.db.profile.MainWindow.TextHeight == nil then VoidMark.db.profile.MainWindow.TextHeight = Default_Profile.profile.MainWindow.TextHeight end
	if VoidMark.db.profile.MainWindow.AutoHide == nil then VoidMark.db.profile.MainWindow.AutoHide = Default_Profile.profile.MainWindow.AutoHide end
	if VoidMark.db.profile.MainWindow.BarText == nil then VoidMark.db.profile.MainWindow.BarText = Default_Profile.profile.MainWindow.BarText end
	if VoidMark.db.profile.MainWindow.BarText.RankNum == nil then VoidMark.db.profile.MainWindow.BarText.RankNum = Default_Profile.profile.MainWindow.BarText.RankNum end
	if VoidMark.db.profile.MainWindow.BarText.PerSec == nil then VoidMark.db.profile.MainWindow.BarText.PerSec = Default_Profile.profile.MainWindow.BarText.PerSec end
	if VoidMark.db.profile.MainWindow.BarText.Percent == nil then VoidMark.db.profile.MainWindow.BarText.Percent = Default_Profile.profile.MainWindow.BarText.Percent end
	if VoidMark.db.profile.MainWindow.BarText.NumFormat == nil then VoidMark.db.profile.MainWindow.BarText.NumFormat = Default_Profile.profile.MainWindow.BarText.NumFormat end
	if VoidMark.db.profile.MainWindow.Position == nil then VoidMark.db.profile.MainWindow.Position = Default_Profile.profile.MainWindow.Position end
	if VoidMark.db.profile.MainWindow.Position.x == nil then VoidMark.db.profile.MainWindow.Position.x = Default_Profile.profile.MainWindow.Position.x end
	if VoidMark.db.profile.MainWindow.Position.y == nil then VoidMark.db.profile.MainWindow.Position.y = Default_Profile.profile.MainWindow.Position.y end
	if VoidMark.db.profile.MainWindow.Position.w == nil then VoidMark.db.profile.MainWindow.Position.w = Default_Profile.profile.MainWindow.Position.w end
	if VoidMark.db.profile.MainWindow.Position.h == nil then VoidMark.db.profile.MainWindow.Position.h = Default_Profile.profile.MainWindow.Position.h end
	if VoidMark.db.profile.AlertWindowNameSize == nil then VoidMark.db.profile.AlertWindowNameSize = Default_Profile.profile.AlertWindowNameSize end
	if VoidMark.db.profile.AlertWindowLocationSize == nil then VoidMark.db.profile.AlertWindowLocationSize = Default_Profile.profile.AlertWindowLocationSize end
	if VoidMark.db.profile.BarTexture == nil then VoidMark.db.profile.BarTexture = Default_Profile.profile.BarTexture end
	if VoidMark.db.profile.MainWindowVis == nil then VoidMark.db.profile.MainWindowVis = Default_Profile.profile.MainWindowVis end
	if VoidMark.db.profile.CurrentList == nil then VoidMark.db.profile.CurrentList = Default_Profile.profile.CurrentList end
	if VoidMark.db.profile.Locked == nil then VoidMark.db.profile.Locked = Default_Profile.profile.Locked end
	if VoidMark.db.profile.Font == nil then VoidMark.db.profile.Font = Default_Profile.profile.Font end
	if VoidMark.db.profile.Scaling == nil then VoidMark.db.profile.Scaling = Default_Profile.profile.Scaling end
	if VoidMark.db.profile.Enabled == nil then VoidMark.db.profile.Enabled = Default_Profile.profile.Enabled end
	if VoidMark.db.profile.EnabledInBattlegrounds == nil then VoidMark.db.profile.EnabledInBattlegrounds = Default_Profile.profile.EnabledInBattlegrounds end
	if VoidMark.db.profile.EnabledInSanctuaries == nil then VoidMark.db.profile.EnabledInSanctuaries = Default_Profile.profile.EnabledInSanctuaries end
	if VoidMark.db.profile.EnabledInArenas == nil then VoidMark.db.profile.EnabledInArenas = Default_Profile.profile.EnabledInArenas end
	if VoidMark.db.profile.EnabledInWintergrasp == nil then VoidMark.db.profile.EnabledInWintergrasp = Default_Profile.profile.EnabledInWintergrasp end
	if VoidMark.db.profile.DisableWhenPVPUnflagged == nil then VoidMark.db.profile.DisableWhenPVPUnflagged = Default_Profile.profile.DisableWhenPVPUnflagged end
	if VoidMark.db.profile.IgnoreBattlegroundStats == nil then VoidMark.db.profile.IgnoreBattlegroundStats = Default_Profile.profile.IgnoreBattlegroundStats end
	if VoidMark.db.profile.MinimapDetection == nil then VoidMark.db.profile.MinimapDetection = Default_Profile.profile.MinimapDetection end
	if VoidMark.db.profile.MinimapDetails == nil then VoidMark.db.profile.MinimapDetails = Default_Profile.profile.MinimapDetails end
	if VoidMark.db.profile.DisplayOnMap == nil then VoidMark.db.profile.DisplayOnMap = Default_Profile.profile.DisplayOnMap end
	if VoidMark.db.profile.SwitchToZone == nil then VoidMark.db.profile.SwitchToZone = Default_Profile.profile.SwitchToZone end	
	if VoidMark.db.profile.MapDisplayLimit == nil then VoidMark.db.profile.MapDisplayLimit = Default_Profile.profile.MapDisplayLimit end
	if VoidMark.db.profile.DisplayTooltipNearVoidMarkWindow == nil then VoidMark.db.profile.DisplayTooltipNearVoidMarkWindow = Default_Profile.profile.DisplayTooltipNearVoidMarkWindow end	
	if VoidMark.db.profile.TooltipAnchor == nil then VoidMark.db.profile.TooltipAnchor = Default_Profile.profile.TooltipAnchor end	
	if VoidMark.db.profile.DisplayWinLossStatistics == nil then VoidMark.db.profile.DisplayWinLossStatistics = Default_Profile.profile.DisplayWinLossStatistics end
	if VoidMark.db.profile.DisplayKOSReason == nil then VoidMark.db.profile.DisplayKOSReason = Default_Profile.profile.DisplayKOSReason end
	if VoidMark.db.profile.DisplayLastSeen == nil then VoidMark.db.profile.DisplayLastSeen = Default_Profile.profile.DisplayLastSeen end
	if VoidMark.db.profile.ShowOnDetection == nil then VoidMark.db.profile.ShowOnDetection = Default_Profile.profile.ShowOnDetection end
	if VoidMark.db.profile.HideVoidMark == nil then VoidMark.db.profile.HideVoidMark = Default_Profile.profile.HideVoidMark end
--	if VoidMark.db.profile.ShowOnlyPvPFlagged == nil then VoidMark.db.profile.ShowOnlyPvPFlagged = Default_Profile.profile.ShowOnlyPvPFlagged end	
	if VoidMark.db.profile.ShowKoSButton == nil then VoidMark.db.profile.ShowKoSButton = Default_Profile.profile.ShowKoSButton end	
	if VoidMark.db.profile.InvertVoidMark == nil then VoidMark.db.profile.InvertVoidMark = Default_Profile.profile.InvertVoidMark end
	if VoidMark.db.profile.ResizeVoidMark == nil then VoidMark.db.profile.ResizeVoidMark = Default_Profile.profile.ResizeVoidMark end
	if VoidMark.db.profile.ResizeVoidMarkLimit == nil then VoidMark.db.profile.ResizeVoidMarkLimit = Default_Profile.profile.ResizeVoidMarkLimit end 
	if VoidMark.db.profile.Announce == nil then VoidMark.db.profile.Announce = Default_Profile.profile.Announce end
	if VoidMark.db.profile.OnlyAnnounceKoS == nil then VoidMark.db.profile.OnlyAnnounceKoS = Default_Profile.profile.OnlyAnnounceKoS end
	if VoidMark.db.profile.WarnOnStealth == nil then VoidMark.db.profile.WarnOnStealth = Default_Profile.profile.WarnOnStealth end
	if VoidMark.db.profile.WarnOnKOS == nil then VoidMark.db.profile.WarnOnKOS = Default_Profile.profile.WarnOnKOS end
	if VoidMark.db.profile.WarnOnKOSGuild == nil then VoidMark.db.profile.WarnOnKOSGuild = Default_Profile.profile.WarnOnKOSGuild end
	if VoidMark.db.profile.WarnOnRace == nil then VoidMark.db.profile.WarnOnRace = Default_Profile.profile.WarnOnRace end
	if VoidMark.db.profile.SelectWarnRace == nil then VoidMark.db.profile.SelectWarnRace = Default_Profile.profile.SelectWarnRace end
	if VoidMark.db.profile.DisplayWarningsInErrorsFrame == nil then VoidMark.db.profile.DisplayWarningsInErrorsFrame = Default_Profile.profile.DisplayWarningsInErrorsFrame end
	if VoidMark.db.profile.EnableSound == nil then VoidMark.db.profile.EnableSound = Default_Profile.profile.EnableSound end
	if VoidMark.db.profile.OnlySoundKoS == nil then VoidMark.db.profile.OnlySoundKoS = Default_Profile.profile.OnlySoundKoS end	
	if VoidMark.db.profile.StopAlertsOnTaxi == nil then VoidMark.db.profile.StopAlertsOnTaxi = Default_Profile.profile.StopAlertsOnTaxi end 	
	if VoidMark.db.profile.RemoveUndetected == nil then VoidMark.db.profile.RemoveUndetected = Default_Profile.profile.RemoveUndetected end
	if VoidMark.db.profile.ShowNearbyList == nil then VoidMark.db.profile.ShowNearbyList = Default_Profile.profile.ShowNearbyList end

	-- VoidMark behavior migration: as of 2026-10-02 the window stays visible
	-- when unflagged by default, and battleground combat is excluded from stats.
	VoidMarkDB.VoidMarkBehaviorVersion = tonumber(VoidMarkDB.VoidMarkBehaviorVersion) or 0
	if VoidMarkDB.VoidMarkBehaviorVersion < 1 then
		VoidMark.db.profile.DisableWhenPVPUnflagged = false
		VoidMark.db.profile.HideVoidMark = false
		VoidMark.db.profile.IgnoreBattlegroundStats = true
		VoidMarkDB.VoidMarkBehaviorVersion = 1
	end
	if VoidMark.db.profile.PrioritiseKoS == nil then VoidMark.db.profile.PrioritiseKoS = Default_Profile.profile.PrioritiseKoS end
	if VoidMark.db.profile.PurgeData == nil then VoidMark.db.profile.PurgeData = Default_Profile.profile.PurgeData end
	if VoidMark.db.profile.PurgeKoS == nil then VoidMark.db.profile.PurgeKoS = Default_Profile.profile.PurgeKoSData end	
	if VoidMark.db.profile.PurgeWinLossData == nil then VoidMark.db.profile.PurgeWinLossData = Default_Profile.profile.PurgeWinLossData end	
	if VoidMark.db.profile.ShareData == nil then VoidMark.db.profile.ShareData = Default_Profile.profile.ShareData end
	if VoidMark.db.profile.UseData == nil then VoidMark.db.profile.UseData = Default_Profile.profile.UseData end
	if VoidMark.db.profile.ShareKOSBetweenCharacters == nil then VoidMark.db.profile.ShareKOSBetweenCharacters = Default_Profile.profile.ShareKOSBetweenCharacters end
	if VoidMark.db.profile.AppendUnitNameCheck == nil then VoidMark.db.profile.AppendUnitNameCheck = Default_Profile.profile.AppendUnitNameCheck end
	if VoidMark.db.profile.AppendUnitKoSCheck == nil then VoidMark.db.profile.AppendUnitKoSCheck = Default_Profile.profile.AppendUnitKoSCheck end	]]--
end

function VoidMark:ResetProfile()
	VoidMark.db.profile = Default_Profile.profile
--	VoidMark:CheckDatabase()
end

function VoidMark:HandleProfileChanges()
	VoidMark:SanitizeStage1Profile()
	VoidMark:CreateMainWindow()
	VoidMark:RestoreMainWindowPosition(VoidMark.db.profile.MainWindow.Position.x, VoidMark.db.profile.MainWindow.Position.y, VoidMark.db.profile.MainWindow.Position.w, 34)
	VoidMark:ResizeMainWindow()
	VoidMark:UpdateTimeoutSettings()
	VoidMark:LockWindows(VoidMark.db.profile.Locked)
	VoidMark:ClampToScreen(VoidMark.db.profile.ClampToScreen)
end

function VoidMark:RegisterModuleOptions(name, optionTbl, displayName)
	VoidMark.options.args[name] = (type(optionTbl) == "function") and optionTbl() or optionTbl
	local frame, categoryID = LibStub("AceConfigDialog-3.0"):AddToBlizOptions("VoidMark", displayName, L["VoidMark Option"], name)
	self.optionsFrames[name] = frame
	self.optionsCategoryIDs[name] = categoryID or (frame and frame.name)
end

function VoidMark:SetupOptions()
	self.optionsFrames = {}
	self.optionsCategoryIDs = {}

 	LibStub("AceConfigRegistry-3.0"):RegisterOptionsTable("VoidMark", VoidMark.options)
	-- Public commands use the VoidMark name; SavedVariables retain compatibility.
	LibStub("AceConfig-3.0"):RegisterOptionsTable("VoidMark Commands", VoidMark.optionsSlash, {"voidmark", "vm"})

	local ACD3 = LibStub("AceConfigDialog-3.0")
	local function AddOptionsFrame(key, appName, displayName, parent, group)
		local frame, categoryID = ACD3:AddToBlizOptions(appName, displayName, parent, group)
		self.optionsFrames[key] = frame
		self.optionsCategoryIDs[key] = categoryID or (frame and frame.name)
	end

	AddOptionsFrame("VoidMark", "VoidMark", L["VoidMark Option"], nil, "General")
	AddOptionsFrame("About", "VoidMark", L["About"], L["VoidMark Option"], "About")
	AddOptionsFrame("DisplayOptions", "VoidMark", L["DisplayOptions"], L["VoidMark Option"], "DisplayOptions")
	AddOptionsFrame("AlertOptions", "VoidMark", L["AlertOptions"], L["VoidMark Option"], "AlertOptions")
	AddOptionsFrame("TrackingOptions", "VoidMark", "Tracking", L["VoidMark Option"], "TrackingOptions")

	self:RegisterModuleOptions("Profiles", LibStub("AceDBOptions-3.0"):GetOptionsTable(self.db), L["Profiles"])
	VoidMark.options.args.Profiles.order = -2
end

function VoidMark:UpdateTimeoutSettings()
	if not VoidMark.db.profile.RemoveUndetected or VoidMark.db.profile.RemoveUndetected == "OneMinute" then
		VoidMark.ActiveTimeout = 30
		VoidMark.InactiveTimeout = 60
	elseif VoidMark.db.profile.RemoveUndetected == "TwoMinutes" then
		VoidMark.ActiveTimeout = 60
		VoidMark.InactiveTimeout = 120
	elseif VoidMark.db.profile.RemoveUndetected == "FiveMinutes" then
		VoidMark.ActiveTimeout = 150
		VoidMark.InactiveTimeout = 300
	elseif VoidMark.db.profile.RemoveUndetected == "TenMinutes" then
		VoidMark.ActiveTimeout = 300
		VoidMark.InactiveTimeout = 600
	elseif VoidMark.db.profile.RemoveUndetected == "FifteenMinutes" then
		VoidMark.ActiveTimeout = 450
		VoidMark.InactiveTimeout = 900
	elseif VoidMark.db.profile.RemoveUndetected == "Never" then
		VoidMark.ActiveTimeout = 30
		VoidMark.InactiveTimeout = -1
	else
		VoidMark.ActiveTimeout = 150
		VoidMark.InactiveTimeout = 300
	end
end

function VoidMark:ResetMainWindow() -- not used
	VoidMark:EnableVoidMark(true, true)
	VoidMark:CreateMainWindow()
	VoidMark:RestoreMainWindowPosition(Default_Profile.profile.MainWindow.Position.x, Default_Profile.profile.MainWindow.Position.y, Default_Profile.profile.MainWindow.Position.w, 34)
	VoidMark:RefreshCurrentList()
end

function VoidMark:ResetPositions()
	VoidMark:ResetPositionAllWindows()
end

function VoidMark:ShowConfig()
	-- Current Classic Settings expects a registered category ID. Prefer a
	-- numeric child-category ID because passing display-name strings can throw.
	local frames = self.optionsFrames or {}
	local ids = self.optionsCategoryIDs or {}
	local preferred = {"DisplayOptions", "Profiles", "About", "VoidMark"}

	if Settings and Settings.OpenToCategory then
		for _, key in ipairs(preferred) do
			local frame = frames[key]
			local categoryID = ids[key] or (frame and frame.name)
			if type(categoryID) == "number" then
				local ok = pcall(Settings.OpenToCategory, categoryID)
				if ok then return end
			end
		end

		-- Compatibility fallback for clients/AceConfig builds that still use a
		-- non-numeric registered ID. pcall prevents the old settings crash.
		for _, key in ipairs(preferred) do
			local frame = frames[key]
			local categoryID = ids[key] or (frame and frame.name)
			if categoryID ~= nil then
				local ok = pcall(Settings.OpenToCategory, categoryID)
				if ok then return end
			end
		end
	end

	-- Fallback for older clients / AceConfig versions.
	local optionsFrame = frames.DisplayOptions or frames.Profiles or frames.VoidMark
	if InterfaceOptionsFrame_OpenToCategory and optionsFrame then
		InterfaceOptionsFrame_OpenToCategory(optionsFrame)
	end
end

function VoidMark:OnEnable(first)
	VoidMark.timeid = VoidMark:ScheduleRepeatingTimer("ManageExpirations", 10, true)
	VoidMarkForever.RegisterEvent(VoidMark,"ZONE_CHANGED", "ZoneChangedEvent")
	VoidMarkForever.RegisterEvent(VoidMark,"ZONE_CHANGED_INDOORS", "ZoneChangedEvent")
--	VoidMarkForever.RegisterEvent(VoidMark,"ZONE_CHANGED_NEW_AREA", "ZoneChangedEvent")
	VoidMarkForever.RegisterEvent(VoidMark,"ZONE_CHANGED_NEW_AREA", "ZoneChangedNewAreaEvent")
--	VoidMarkForever.RegisterEvent(VoidMark,"PLAYER_ENTERING_WORLD", "ZoneChangedEvent")
	VoidMarkForever.RegisterEvent(VoidMark,"PLAYER_ENTERING_WORLD", "PlayerEnteringWorldEvent")
	VoidMarkForever.RegisterEvent(VoidMark,"UNIT_FACTION", "ZoneChangedEvent")
	VoidMarkForever.RegisterEvent(VoidMark,"PLAYER_FLAGS_CHANGED", "ZoneChangedEvent")
	VoidMarkForever.RegisterEvent(VoidMark,"PLAYER_TARGET_CHANGED", "PlayerTargetEvent")
	VoidMarkForever.RegisterEvent(VoidMark,"UPDATE_MOUSEOVER_UNIT", "PlayerMouseoverEvent")
	VoidMarkForever.RegisterEvent(VoidMark,"COMBAT_LOG_EVENT_UNFILTERED", "CombatLogEvent")
	VoidMarkForever.RegisterEvent(VoidMark,"UNIT_PET", "UnitPets")
	VoidMarkForever.RegisterEvent(VoidMark,"PLAYER_REGEN_ENABLED", "LeftCombatEvent")
	VoidMarkForever.RegisterEvent(VoidMark,"PLAYER_DEAD", "PlayerDeadEvent")
	VoidMarkForever.RegisterEvent(VoidMark,"CHAT_MSG_CHANNEL_NOTICE", "ChannelNoticeEvent")
	-- VoidMark: only inspect a nameplate while its unit token is valid.
	-- NAME_PLATE_UNIT_REMOVED can arrive after the token is no longer queryable
	-- in Classic Era and can trigger ERR_NAME_PLATE_UNIT_NAME_REQUIRED.
	VoidMarkForever.RegisterEvent(VoidMark,"NAME_PLATE_UNIT_ADDED", "NamePlateEvent")
	VoidMark.IsEnabled = true
--	VoidMark:RefreshCurrentList()
end

function VoidMark:OnDisable()
	if not VoidMark.IsEnabled then
		return
	end
	if VoidMark.timeid then
		VoidMark:CancelTimer(VoidMark.timeid)
		VoidMark.timeid = nil
	end
	VoidMark:UnregisterEvent("ZONE_CHANGED")
	VoidMark:UnregisterEvent("ZONE_CHANGED_NEW_AREA")
	VoidMark:UnregisterEvent("ZONE_CHANGED_INDOORS")
	VoidMark:UnregisterEvent("PLAYER_ENTERING_WORLD")
	VoidMark:UnregisterEvent("UNIT_FACTION")
	VoidMark:UnregisterEvent("PLAYER_FLAGS_CHANGED")
	VoidMark:UnregisterEvent("PLAYER_TARGET_CHANGED")
	VoidMark:UnregisterEvent("UPDATE_MOUSEOVER_UNIT")
	VoidMark:UnregisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
	VoidMark:UnregisterEvent("PLAYER_REGEN_ENABLED")
	VoidMark:UnregisterEvent("PLAYER_DEAD")
	VoidMark:UnregisterEvent("CHAT_MSG_CHANNEL_NOTICE")
	VoidMark:UnregisterEvent("NAME_PLATE_UNIT_ADDED")
	VoidMark:UnregisterEvent("NAME_PLATE_UNIT_REMOVED")
	VoidMark:UnregisterComm(VoidMark.Signature)
	VoidMark.IsEnabled = false
end

function VoidMark:EnableVoidMark(value, changeDisplay, hideEnabledMessage)
	VoidMark.db.profile.Enabled = value
	if value then
		if changeDisplay and not InCombatLockdown() then
			VoidMark.MainWindow:Show()
		end
		VoidMark:OnEnable()
		if not hideEnabledMessage then
			DEFAULT_CHAT_FRAME:AddMessage(L["VoidMarkEnabled"])
		end
	else
		if changeDisplay and not InCombatLockdown() then
			VoidMark.MainWindow:Hide()
		end
		VoidMark:OnDisable()
		DEFAULT_CHAT_FRAME:AddMessage(L["VoidMarkDisabled"])
	end
end

function VoidMark:EnableSound(value)
	VoidMark.db.profile.EnableSound = value
	if value then
		DEFAULT_CHAT_FRAME:AddMessage(L["SoundEnabled"]) 
	else
		DEFAULT_CHAT_FRAME:AddMessage(L["SoundDisabled"])
	end
end

local TALIAA_WHITEMANE_CLUSTER_REALMS = {
	["Forever"] = true,
	["Thunderfury"] = true,
	["Fairbanks"] = true,
	["Anathema"] = true,
	["Arcanite Reaper"] = true,
	["Bigglesworth"] = true,
	["Blaumeux"] = true,
	["Kurinnaxx"] = true,
	["Rattlegore"] = true,
	["Smolderweb"] = true,
}

local function TaliaaCanonicalRealm(realm)
	if VoidMarkForever.IsForever then return "Forever" end
	if TALIAA_WHITEMANE_CLUSTER_REALMS[realm] then
		return "Forever"
	end
	return realm
end

local function TaliaaCopyMissing(dst, src)
	if type(dst) ~= "table" or type(src) ~= "table" then return end
	for key, value in pairs(src) do
		if dst[key] == nil then
			if type(value) == "table" then
				local copy = {}
				TaliaaCopyMissing(copy, value)
				dst[key] = copy
			else
				dst[key] = value
			end
		elseif type(dst[key]) == "table" and type(value) == "table" then
			TaliaaCopyMissing(dst[key], value)
		end
	end
end

function VoidMark:RecoverLegacyKOS(force)
	if not VoidMarkDB or not VoidMarkPerCharDB or not VoidMark.FactionName then return 0 end

	VoidMarkPerCharDB.KOSData = VoidMarkPerCharDB.KOSData or {}
	VoidMarkPerCharDB.PlayerData = VoidMarkPerCharDB.PlayerData or {}

	VoidMarkDB.VoidMarkKOSRecovery = VoidMarkDB.VoidMarkKOSRecovery or {}
	local recoveryKey = tostring(VoidMark.RealmName or "?") .. "|" .. tostring(VoidMark.FactionName or "?")
	if not force and tonumber(VoidMarkDB.VoidMarkKOSRecovery[recoveryKey]) and VoidMarkDB.VoidMarkKOSRecovery[recoveryKey] >= 1 then
		return 0
	end

	-- Preserve a forensic snapshot of every name we can still find before
	-- changing anything. We intentionally ignore old removeKOSData tombstones:
	-- those stale tombstones are the bug that could empty the shared KOS list.
	VoidMarkDB.VoidMarkKOSRecoveryBackup = VoidMarkDB.VoidMarkKOSRecoveryBackup or {}
	local backup = {
		time = time(),
		existing = {},
		legacy = {},
		playerFlags = {},
	}
	VoidMarkDB.VoidMarkKOSRecoveryBackup[recoveryKey] = backup

	local recovered = {}
	local recoveredInfo = {}

	local function Remember(name, added, info, source)
		if type(name) ~= "string" or name == "" then return end
		local stamp = tonumber(added) or (type(info) == "table" and tonumber(info.added)) or time()
		local current = recovered[name]
		if current == nil or stamp > current then
			recovered[name] = stamp
		end
		if type(info) == "table" then
			recoveredInfo[name] = recoveredInfo[name] or info
		end
		if source then
			backup[source][name] = stamp
		end
	end

	-- Source 1: anything that survived in the authoritative shared list.
	for name, added in pairs(VoidMarkPerCharDB.KOSData) do
		Remember(name, added, VoidMarkPerCharDB.PlayerData[name], "existing")
	end

	-- Source 2: PlayerData.kos flags sometimes survive after KOSData was removed.
	for name, info in pairs(VoidMarkPerCharDB.PlayerData) do
		if type(info) == "table" and info.kos == 1 then
			Remember(name, info.time, info, "playerFlags")
		end
	end

	-- Source 3: old VoidMark per-character central KOS mirrors. Union every character
	-- on the current faction across realms that canonicalize to this cluster.
	if type(VoidMarkDB.kosData) == "table" then
		for realm, realmData in pairs(VoidMarkDB.kosData) do
			if TaliaaCanonicalRealm(realm) == VoidMark.RealmName and type(realmData) == "table" then
				local factionData = realmData[VoidMark.FactionName]
				if type(factionData) == "table" then
					for _, characterData in pairs(factionData) do
						if type(characterData) == "table" then
							for name, info in pairs(characterData) do
								if type(info) == "table" then
									Remember(name, info.added, info, "legacy")
								end
							end
						end
					end
				end
			end
		end
	end

	local before = 0
	for _ in pairs(VoidMarkPerCharDB.KOSData) do before = before + 1 end

	for name, added in pairs(recovered) do
		VoidMarkPerCharDB.KOSData[name] = added
		local dst = VoidMarkPerCharDB.PlayerData[name]
		local src = recoveredInfo[name]
		if type(dst) ~= "table" then
			dst = {}
			VoidMarkPerCharDB.PlayerData[name] = dst
		end
		if type(src) == "table" and src ~= dst then
			TaliaaCopyMissing(dst, src)
		end
		dst.name = dst.name or name
		dst.kos = 1
	end

	-- Retire destructive tombstones for this faction/cluster.
	if type(VoidMarkDB.removeKOSData) == "table" then
		for realm, realmData in pairs(VoidMarkDB.removeKOSData) do
			if TaliaaCanonicalRealm(realm) == VoidMark.RealmName and type(realmData) == "table" then
				realmData[VoidMark.FactionName] = {}
			end
		end
	end

	VoidMarkDB.VoidMarkKOSRecovery[recoveryKey] = 1

	local after = 0
	for _ in pairs(VoidMarkPerCharDB.KOSData) do after = after + 1 end
	local restored = math.max(0, after - before)

	if DEFAULT_CHAT_FRAME then
		DEFAULT_CHAT_FRAME:AddMessage(string.format(
			"|cffb86cff[VoidMark]|r KOS recovery: %d total, %d restored from surviving legacy data.",
			after, restored
		))
	end

	return restored
end

function VoidMark:MigrateClusterRealmData()
	if not VoidMarkDB or not VoidMark.ActualRealmName or VoidMark.ActualRealmName == VoidMark.RealmName then return end

	-- Preserve legacy KOS mirrors for one-time recovery only. Do NOT migrate
	-- removeKOSData tombstones into the canonical cluster; those stale markers
	-- caused valid KOS entries to be deleted on login in older VoidMark builds.
	VoidMarkDB.kosData = VoidMarkDB.kosData or {}
	VoidMarkDB.kosData[VoidMark.RealmName] = VoidMarkDB.kosData[VoidMark.RealmName] or {}
	if VoidMarkDB.kosData[VoidMark.ActualRealmName] then
		TaliaaCopyMissing(VoidMarkDB.kosData[VoidMark.RealmName], VoidMarkDB.kosData[VoidMark.ActualRealmName])
	end
end
function VoidMark:SanitizeStage1Profile()
	if not VoidMark.db or not VoidMark.db.profile then return end
	local profile = VoidMark.db.profile
	profile.MainWindow = profile.MainWindow or {}
	local mw = profile.MainWindow

	local rowHeight = tonumber(mw.RowHeight)
	if not rowHeight or rowHeight < 8 or rowHeight > 20 then mw.RowHeight = 14 end
	local rowSpacing = tonumber(mw.RowSpacing)
	if not rowSpacing or rowSpacing < 0 or rowSpacing > 10 then mw.RowSpacing = 2 end
	local textHeight = tonumber(mw.TextHeight)
	if not textHeight or textHeight < 8 or textHeight > 20 then mw.TextHeight = 12 end

	mw.Position = mw.Position or {}
	local width = tonumber(mw.Position.w)
	if not width or width < 140 or width > 600 then mw.Position.w = 200 end

	local maxListMode = (VoidMark.ListTypes and #VoidMark.ListTypes) or 4
	if type(profile.CurrentList) ~= "number" or profile.CurrentList < 1 or profile.CurrentList > maxListMode then
		profile.CurrentList = 1
	end

	-- One-time cleanup for legacy per-character profiles. This fixes characters
	-- that inherited oversized rows or opened on an old list mode while leaving
	-- the shared player/KOS/history database untouched.
	VoidMarkDB.TaliaaStage1ProfileFix = VoidMarkDB.TaliaaStage1ProfileFix or {}
	local key = table.concat({ tostring(VoidMark.ActualRealmName or VoidMark.RealmName or "?"), tostring(VoidMark.FactionName or "?"), tostring(VoidMark.CharacterName or "?") }, "|")
	if not VoidMarkDB.TaliaaStage1ProfileFix[key] then
		profile.CurrentList = 1
		profile.Locked = false
		VoidMarkDB.TaliaaStage1ProfileFix[key] = true
	end

	-- VoidMark policy: history is permanent. These legacy VoidMark settings are no
	-- longer user-configurable and cannot be re-enabled by an old profile.
	profile.PurgeData = "Never"
	profile.PurgeKoS = false
	-- VoidMark uses VoidMarkDB.TaliaaShared for account-wide KOS persistence.
	-- Disable VoidMark's retired kosData/removeKOSData synchronization layer; stale
	-- deletion tombstones in that layer could erase the real shared KOS list.
	profile.ShareKOSBetweenCharacters = false
	profile.PurgeWinLossData = false
	profile.ShareData = false
	profile.UseData = false
	profile.MinimapDetection = false
	profile.MinimapDetails = false
	profile.DisplayOnMap = false
	profile.SwitchToZone = false
	profile.MapDisplayLimit = "None"
end

function VoidMark:OnInitialize()
	VoidMark.ActualRealmName = GetRealmName()
	VoidMark.RealmName = TaliaaCanonicalRealm(VoidMark.ActualRealmName)
    VoidMark.FactionName = select(1, VMAPI.UnitFactionGroup("player"))
	if VoidMark.FactionName == "Alliance" then
		VoidMark.EnemyFactionName = "Horde"
	elseif VoidMark.FactionName == "Horde" then
		VoidMark.EnemyFactionName = "Alliance"
	else
		VoidMark.EnemyFactionName = "None"
	end
	VoidMark.CharacterName = VMAPI.UnitName("player")

	VoidMark.ValidClasses = {
		["DRUID"] = true,
		["HUNTER"] = true,
		["MAGE"] = true,
		["PALADIN"] = true,
		["PRIEST"] = true,
		["ROGUE"] = true,
		["SHAMAN"] = true,
		["WARLOCK"] = true,
		["WARRIOR"] = true,
--		["DEATHKNIGHT"] = true,
--		["MONK"] = true,
--		["DEMONHUNTER"] = true,
--		["EVOKER"] = true,
	}

	VoidMark.ValidRaces = {
		["Human"] = true,
		["Orc"] = true,
		["Dwarf"] = true,
		["Tauren"] = true,
		["Troll"] = true,
		["NightElf"] = true,
		["Scourge"] = true,
		["Gnome"] = true,
--		["BloodElf"] = true,
--		["Draenei"] = true,
--		["Goblin"] = true,
--		["Worgen"] = true,
--		["Pandaren"] = true,
--		["HighmountainTauren"] = true,
--		["LightforgedDraenei"] = true,
--		["Nightborne"] = true,
--		["VoidElf"] = true,
--		["DarkIronDwarf"] = true,
--		["MagharOrc"] = true,
--		["KulTiran"] = true,
--		["ZandalariTroll"] = true,
--		["Mechagnome"] = true,
--		["Vulpera"] = true,
--		["Dracthyr"] = true,
--		["Earthen"] = true,
	}

	local acedb = LibStub:GetLibrary("AceDB-3.0")

	VoidMark.db = acedb:New("VoidMarkDB", Default_Profile)

	-- One-time behavior migration for existing profiles. AceDB preserves old
	-- profile values, so changing defaults alone would not make current installs
	-- stay visible or exclude battleground stats.
	VoidMarkDB.VoidMarkBehaviorVersion = tonumber(VoidMarkDB.VoidMarkBehaviorVersion) or 0
	if VoidMarkDB.VoidMarkBehaviorVersion < 1 then
		VoidMark.db.profile.DisableWhenPVPUnflagged = false
		VoidMark.db.profile.HideVoidMark = false
		VoidMark.db.profile.IgnoreBattlegroundStats = true
		VoidMarkDB.VoidMarkBehaviorVersion = 1
	end

	VoidMark:MigrateClusterRealmData()
	VoidMark:SanitizeStage1Profile()
	VoidMark:CheckDatabase()

--	self.db.RegisterCallback(self, "OnNewProfile", "ResetProfile")
	self.db.RegisterCallback(self, "OnNewProfile", "HandleProfileChanges")
--	self.db.RegisterCallback(self, "OnProfileReset", "ResetProfile")
	self.db.RegisterCallback(self, "OnProfileReset", "HandleProfileChanges")
	self.db.RegisterCallback(self, "OnProfileChanged", "HandleProfileChanges")
	self.db.RegisterCallback(self, "OnProfileCopied", "HandleProfileChanges")
	self:SetupOptions()

	VoidMarkTempTooltip = CreateFrame("GameTooltip", "VoidMarkTempTooltip", nil, "GameTooltipTemplate")
	VoidMarkTempTooltip:SetOwner(UIParent, "ANCHOR_NONE")

	-- Recover KOS names from surviving legacy mirrors once, then use only
	-- TaliaaShared.KOSData. Never consume removeKOSData tombstones again.
	VoidMark:RecoverLegacyKOS(false)
	VoidMark:RegenerateKOSGuildList()
	VoidMark:PurgeUndetectedData()
	VoidMark:CreateMainWindow()
	VoidMark:CreateKoSButton()
	VoidMark:UpdateTimeoutSettings()

	SM.RegisterCallback(VoidMark, "LibSharedMedia_Registered", "UpdateBarTextures")
	SM.RegisterCallback(VoidMark, "LibSharedMedia_SetGlobal", "UpdateBarTextures")
	if VoidMark.db.profile.BarTexture then
		VoidMark:SetBarTextures(VoidMark.db.profile.BarTexture)
	end

	VoidMark:LockWindows(VoidMark.db.profile.Locked)
	VoidMark:ClampToScreen(VoidMark.db.profile.ClampToScreen)	
	ChatFrame_AddMessageEventFilter("CHAT_MSG_SYSTEM", VoidMark.FilterNotInParty)
	VoidMark.WoWBuildInfo = select(4, GetBuildInfo())
	if VoidMark.WoWBuildInfo > 20000 then
		DEFAULT_CHAT_FRAME:AddMessage(L["VersionCheck"])
	end
end

function VoidMark:ChannelNoticeEvent(_, chStatus, _, _, Channel)
	if chStatus ~= "SUSPENDED" then
		VoidMark.ChnlTime = time()
		local channel, zone = string.match(Channel, "(.+) %- (.+)")
--		local subZone = GetSubZoneText()
		local InFilteredZone = VoidMark:InFilteredZone(zone)
		if InFilteredZone then
			VoidMark.EnabledInZone = false
		end
	end
end

function VoidMark:PlayerEnteringWorldEvent()
	VoidMark.EnabledInZone = false
	local now = time()
	if VoidMark.ChnlTime > (now - 6) then
		self:ScheduleTimer("PlayerEnteringWorldEvent",6)
		return	
	else 
		VoidMark:ZoneChanged()
	end
end

function VoidMark:ZoneChangedEvent()
	local now = time()
	if VoidMark.ChnlTime > (now - 6) then
		self:ScheduleTimer("ZoneChangedEvent",6)
		return
	else 
		VoidMark:ZoneChanged()
	end
end

function VoidMark:ZoneChangedNewAreaEvent()
	local now = time()
	if VoidMark.ChnlTime > (now - 6) then
		self:ScheduleTimer("ZoneChangedNewAreaEvent",6)
		return
	else 
		VoidMark:ZoneChanged()
	end
end

function VoidMark:ShouldIgnoreBattlegroundStats()
	if not (VoidMark.db and VoidMark.db.profile and VoidMark.db.profile.IgnoreBattlegroundStats) then
		return false
	end
	local inInstance, instanceType = VMAPI.IsInInstance()
	return inInstance == true and instanceType == "pvp"
end

function VoidMark:ZoneChanged()
	VoidMark.InInstance = false
	local pvpType = VMAPI.GetZonePVPInfo()
 	local zone = GetZoneText()
	local subZone = GetSubZoneText()
	local InFilteredZone = VoidMark:InFilteredZone(zone, subZone)
	if pvpType == "sanctuary" and not VoidMark.db.profile.EnabledInSanctuaries then
		VoidMark.EnabledInZone = false
	else
		VoidMark.EnabledInZone = true
		if zone == "" or InFilteredZone then
			VoidMark.EnabledInZone = false
		else
			VoidMark.EnabledInZone = true
			local inInstance, instanceType = VMAPI.IsInInstance()
			if inInstance then
				VoidMark.InInstance = true
				if instanceType == "party" or instanceType == "raid" or (not VoidMark.db.profile.EnabledInBattlegrounds and instanceType == "pvp") or (not VoidMark.db.profile.EnabledInArenas and instanceType == "arena") then
					VoidMark.EnabledInZone = false
				end
			elseif pvpType == "combat" then
				if not VoidMark.db.profile.EnabledInWintergrasp then
					VoidMark.EnabledInZone = false
				end
--			elseif (pvpType == "friendly" or pvpType == nil) then
			elseif VMAPI.UnitIsPVP("player") == false and VoidMark.db.profile.DisableWhenPVPUnflagged then
				VoidMark.EnabledInZone = false
--				end
			end
		end
	end

	if VoidMark.EnabledInZone then
		if not VoidMark.db.profile.HideVoidMark then
			if not InCombatLockdown() then VoidMark.MainWindow:Show() end
			VoidMark:RefreshCurrentList()
		end
	else
		if not InCombatLockdown() then VoidMark.MainWindow:Hide() end
	end
	VoidMark:UpdateMainWindow()
end

function VoidMark:InFilteredZone(zone, subzone)
	local InFilteredZone = false
	for filteredZone, value in pairs(VoidMark.db.profile.FilteredZones) do
		if zone == filteredZone and value then
			InFilteredZone = true
		elseif subzone == filteredZone and value then
			InFilteredZone = true
--			break
		end
	end
	return InFilteredZone
end

function VoidMark:PlayerTargetEvent()
	local name = GetUnitName("target", true)
	if name and VMAPI.UnitIsPlayer("target") and not VoidMarkPerCharDB.IgnoreData[name] then
		local playerData = VoidMarkPerCharDB.PlayerData[name]
		if VMAPI.UnitIsEnemy("player", "target") then
			name = string.gsub(name, " %- ", "-")

			local learnt = true
			if playerData and playerData.isGuess == false then learnt = false end

			local x, class = VMAPI.UnitClass("target")
			local race = select(1,VMAPI.UnitRace("target"))
			local level = tonumber(VMAPI.UnitLevel("target"))
			local guild = VMAPI.GetGuildInfo("target")
			local faction = select(1,VMAPI.UnitFactionGroup("target"))
			local guess = false
			if level == VoidMark.Skull then
				if playerData and playerData.level then
					if playerData.level > (VMAPI.UnitLevel("player") + 10) and playerData.level < VoidMark.MaximumPlayerLevel then	
						guess = true
						level = nil
					elseif VMAPI.UnitLevel("player") < VoidMark.MaximumPlayerLevel - 9 then
						guess = true
						level = VMAPI.UnitLevel("player") + 10
					end	
				else
					guess = true
					level = VMAPI.UnitLevel("player") + 10
				end
--			else
--				guess = true
--				level = nil
			end
			local rankName, rank = GetPVPRankInfo(VoidMarkForever.API.UnitPVPRank("target"))
			if ( not rank ) then
				rank = nil
			end
			
			VoidMark:UpdatePlayerData(name, class, level, race, guild, faction, true, guess, rank)
			if VoidMark.EnabledInZone then
				VoidMark:AddDetected(name, time(), learnt)
			end
		elseif playerData then
			VoidMark:RemovePlayerData(name)
		end
	end
end

function VoidMark:PlayerMouseoverEvent()
	local name = GetUnitName("mouseover", true)
	if name and VMAPI.UnitIsPlayer("mouseover") and not VoidMarkPerCharDB.IgnoreData[name] then
		local playerData = VoidMarkPerCharDB.PlayerData[name]
		if VMAPI.UnitIsEnemy("player", "mouseover") then
			name = string.gsub(name, " %- ", "-")

			local learnt = true
			if playerData and playerData.isGuess == false then learnt = false end

			local x, class = VMAPI.UnitClass("mouseover")
			local race = select(1,VMAPI.UnitRace("mouseover"))
			local level = tonumber(VMAPI.UnitLevel("mouseover"))
			local guild = VMAPI.GetGuildInfo("mouseover")
			local faction = select(1,VMAPI.UnitFactionGroup("mouseover"))
			local guess = false
			if level == VoidMark.Skull then
				if playerData and playerData.level then
					if playerData.level > (VMAPI.UnitLevel("player") + 10) and playerData.level < VoidMark.MaximumPlayerLevel then	
						guess = true
						level = nil
					elseif VMAPI.UnitLevel("player") < VoidMark.MaximumPlayerLevel - 9 then
						guess = true
						level = VMAPI.UnitLevel("player") + 10
					end	
				else
					guess = true
					level = VMAPI.UnitLevel("player") + 10
				end
--			else
--				guess = true
--				level = nil
			end
			local rankName, rank = GetPVPRankInfo(VoidMarkForever.API.UnitPVPRank("mouseover"))
			if ( not rank ) then
				rank = nil
			end

			VoidMark:UpdatePlayerData(name, class, level, race, guild, faction, true, guess, rank)
			if VoidMark.EnabledInZone then
				VoidMark:AddDetected(name, time(), learnt)
			end
		elseif playerData then 
			VoidMark:RemovePlayerData(name)
		end
	end
end

function VoidMark:NamePlateEvent(event, unit)
	-- Only NAME_PLATE_UNIT_ADDED is registered now, but keep this guard in
	-- place so an invalid/expired nameplate token can never be queried.
	if event ~= "NAME_PLATE_UNIT_ADDED" then return end
	if type(unit) ~= "string" or unit == "" or not VMAPI.UnitExists(unit) then return end

	local name = GetUnitName(unit, true)
	if name and name ~= "" and VMAPI.UnitIsPlayer(unit) and not VoidMarkPerCharDB.IgnoreData[name] then
		local playerData = VoidMarkPerCharDB.PlayerData[name]
		if VMAPI.UnitIsEnemy("player", unit) then
			name = string.gsub(name, " %- ", "-")

			local learnt = true
			if playerData and playerData.isGuess == false then learnt = false end

			local x, class = VMAPI.UnitClass(unit)
			local race = select(1,VMAPI.UnitRace(unit))
			local level = tonumber(VMAPI.UnitLevel(unit))
			local guild = VMAPI.GetGuildInfo(unit)
			local faction = select(1,VMAPI.UnitFactionGroup(unit))
			local guess = false
			if level == VoidMark.Skull then
				if playerData and playerData.level then
					if playerData.level > (VMAPI.UnitLevel("player") + 10) and playerData.level < VoidMark.MaximumPlayerLevel then	
						guess = true
						level = nil
					elseif VMAPI.UnitLevel("player") < VoidMark.MaximumPlayerLevel - 9 then
						guess = true
						level = VMAPI.UnitLevel("player") + 10
					end	
				else
					guess = true
					level = VMAPI.UnitLevel("player") + 10
				end
--			else
--				guess = true
--				level = nil
			end
			local rankName, rank = GetPVPRankInfo(VoidMarkForever.API.UnitPVPRank(unit))
			if ( not rank ) then
				rank = nil
			end

			VoidMark:UpdatePlayerData(name, class, level, race, guild, faction, true, guess, rank)
			if VoidMark.EnabledInZone then
				VoidMark:AddDetected(name, time(), learnt)
			end
		elseif playerData then 
			VoidMark:RemovePlayerData(name)
		end
	end
end


--------------------------------------------------
-- TALIAA SPY THREAT TRACKING
-- Uses VoidMark's existing combat log / death events.
--------------------------------------------------

VoidMark.ThreatCombat = VoidMark.ThreatCombat or {}
VoidMark.ThreatDebug = false

local TALIAA_THREAT_DEATH_CREDIT_WINDOW = 10
local TALIAA_THREAT_FIGHT_TIMEOUT = 15
local TALIAA_THREAT_POST_FIGHT_LOCKOUT = 3

-- Prevent trailing combat-log events from immediately reopening
-- an encounter that just ended as a WIN or LOSS.
VoidMark.ThreatFightLockout = VoidMark.ThreatFightLockout or {}

-- Gank credit is kept separate from the active threat fight.
-- This lets a player still count as a gank if they die from your DoT
-- or shortly after combat drops.
VoidMark.GankRecentDamage = VoidMark.GankRecentDamage or {}
local TALIAA_GANK_CREDIT_WINDOW = 30

local function TaliaaThreatPrint(message)
	if VoidMark.ThreatDebug then
		DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00[Taliaa Threat]|r " .. tostring(message))
	end
end

local function TaliaaThreatIsHostilePlayer(flags, guid)
	if not flags or not guid then
		return false
	end
	if strsub(guid, 1, 6) ~= "Player" then
		return false
	end
	return bit.band(flags, COMBATLOG_OBJECT_REACTION_HOSTILE) == COMBATLOG_OBJECT_REACTION_HOSTILE
end

local function TaliaaThreatGetPlayerData(player)
	if not player or not VoidMarkPerCharDB or not VoidMarkPerCharDB.PlayerData then
		return nil
	end

	local playerData = VoidMarkPerCharDB.PlayerData[player]
	if not playerData then
		return nil
	end

	if not playerData.threatData then
		playerData.threatData = {}
	end

	local threat = playerData.threatData
	if not threat.fights then threat.fights = 0 end
	if not threat.wins then threat.wins = 0 end
	if not threat.losses then threat.losses = 0 end
	if not threat.disengaged then threat.disengaged = 0 end
	if not threat.interrupted then threat.interrupted = 0 end
	if not threat.damageDone then threat.damageDone = 0 end
	if not threat.damageTaken then threat.damageTaken = 0 end
	if not threat.totalCombatTime then threat.totalCombatTime = 0 end
	if not threat.totalWinTime then threat.totalWinTime = 0 end
	if not threat.totalLossTime then threat.totalLossTime = 0 end
	if not threat.threatScore then threat.threatScore = 0 end
	if not threat.threatLevel then threat.threatLevel = 0 end

	return playerData
end


local function TaliaaClamp(value, low, high)
	if value < low then return low end
	if value > high then return high end
	return value
end

local function TaliaaThreatLabel(score)
	if score >= 81 then
		return "EXTREME", "|cffff0000"
	elseif score >= 61 then
		return "DANGEROUS", "|cffff7f00"
	elseif score >= 41 then
		return "EVEN", "|cffffff00"
	elseif score >= 21 then
		return "FAVORABLE", "|cff00ff00"
	else
		return "EASY", "|cff66ff66"
	end
end

local function TaliaaThreatConfidence(completed)
	if completed >= 10 then
		return "High"
	elseif completed >= 5 then
		return "Moderate"
	elseif completed >= 2 then
		return "Low"
	else
		return "Very Low"
	end
end

function VoidMark:CalculateThreatScore(player)
	local playerData = TaliaaThreatGetPlayerData(player)
	if not playerData then return 50, "UNKNOWN", "No Data" end
	local t = playerData.threatData
	local wins, losses = t.wins or 0, t.losses or 0
	local completed = wins + losses
	local score, level = 50, "UNKNOWN"
	if completed > 0 then
		score = math.floor(((losses / completed) * 100) + 0.5)
		if wins > losses then level = "LOW"
		elseif losses > wins then level = "HIGH"
		else level = "EVEN" end
	end
	local confidence = completed == 0 and "No Data" or TaliaaThreatConfidence(completed)
	t.threatScore, t.threatLevel, t.threatConfidence = score, level, confidence
	t.lastThreatUpdate = time()
	return score, level, confidence
end

function VoidMark:StartThreatFight(player)
	if not player then
		return nil
	end

	-- Do not let delayed combat-log events create a new encounter
	-- after the player has already died or released.
	if VMAPI.UnitIsDeadOrGhost("player") then
		return nil
	end

	local lockoutUntil = VoidMark.ThreatFightLockout[player]
	if lockoutUntil then
		if GetTime() < lockoutUntil then
			return nil
		end
		VoidMark.ThreatFightLockout[player] = nil
	end

	local fight = VoidMark.ThreatCombat[player]
	if not fight then
		local now = GetTime()
		fight = {
			startTime = now,
			lastEventTime = now,
			lastTakenTime = nil,
			damageDone = 0,
			damageTaken = 0,
		}
		VoidMark.ThreatCombat[player] = fight
		TaliaaThreatPrint("Fight started: " .. player)
	end

	return fight
end

function VoidMark:FinishThreatFight(player, result)
	local fight = VoidMark.ThreatCombat[player]
	if not fight then
		return
	end

	if VoidMark:ShouldIgnoreBattlegroundStats() then
		VoidMark.ThreatCombat[player] = nil
		return
	end

	local playerData = TaliaaThreatGetPlayerData(player)
	if not playerData then
		VoidMark.ThreatCombat[player] = nil
		return
	end

	local threat = playerData.threatData
	local duration = GetTime() - fight.startTime
	if duration < 0.1 then
		duration = 0.1
	end

	threat.fights = threat.fights + 1
	threat.damageDone = threat.damageDone + fight.damageDone
	threat.damageTaken = threat.damageTaken + fight.damageTaken
	threat.totalCombatTime = threat.totalCombatTime + duration
	threat.lastFightTime = time()
	threat.lastResult = result

	if result == "WIN" then
		threat.wins = threat.wins + 1
		threat.totalWinTime = threat.totalWinTime + duration
		if not threat.fastestWin or duration < threat.fastestWin then
			threat.fastestWin = duration
		end
	elseif result == "LOSS" then
		threat.losses = threat.losses + 1
		threat.totalLossTime = threat.totalLossTime + duration
		if not threat.fastestLoss or duration < threat.fastestLoss then
			threat.fastestLoss = duration
		end
	elseif result == "INTERRUPTED" then
		threat.interrupted = threat.interrupted + 1
	else
		threat.disengaged = threat.disengaged + 1
	end

	local completedFights = threat.wins + threat.losses
	local threatScore, threatLevel, confidence = VoidMark:CalculateThreatScore(player)
	local _, threatColor = TaliaaThreatLabel(threatScore)

	-- Threat results are stored and remain available to the VoidMark window/tooltip,
	-- but completed fights no longer print a summary to the normal chat frame.
	if VoidMark.ThreatDebug and result ~= "WIN" and result ~= "LOSS" then
		TaliaaThreatPrint(string.format(
			"%s | %s | %.1fs | Done: %d | Taken: %d",
			player,
			result,
			duration,
			fight.damageDone,
			fight.damageTaken
		))
	end

	VoidMark.ThreatCombat[player] = nil

	-- Only completed fights get the short lockout. A normal disengagement
	-- can reopen immediately if actual PvP damage resumes.
	if result == "WIN" or result == "LOSS" then
		VoidMark.ThreatFightLockout[player] = GetTime() + TALIAA_THREAT_POST_FIGHT_LOCKOUT
	end
end

function VoidMark:FinishAllThreatFights(result)
	local players = {}
	for player in pairs(VoidMark.ThreatCombat) do
		table.insert(players, player)
	end
	for _, player in ipairs(players) do
		VoidMark:FinishThreatFight(player, result or "DISENGAGED")
	end
end

local function TaliaaThreatDamageAmount(event, arg12, arg13, arg14, arg15)
	if event == "SWING_DAMAGE" then
		return tonumber(arg12) or 0
	elseif event == "RANGE_DAMAGE"
		or event == "SPELL_DAMAGE"
		or event == "SPELL_PERIODIC_DAMAGE"
	then
		return tonumber(arg15) or 0
	end
	return 0
end

local function TaliaaThreatTrackDamage(event, srcGUID, srcName, srcFlags, dstGUID, dstName, dstFlags, arg12, arg13, arg14, arg15)
	local amount = TaliaaThreatDamageAmount(event, arg12, arg13, arg14, arg15)
	if amount <= 0 then
		return
	end

	local playerGUID = VMAPI.UnitGUID("player")
	local now = GetTime()

	-- You damaged a hostile player.
	if srcGUID == playerGUID
		and dstName
		and TaliaaThreatIsHostilePlayer(dstFlags, dstGUID)
	then
		-- Keep independent gank-credit history even if the active
		-- threat encounter later times out or combat drops.
		VoidMark.GankRecentDamage[dstName] = now

		local fight = VoidMark:StartThreatFight(dstName)
		if fight then
			fight.damageDone = fight.damageDone + amount
			fight.lastEventTime = now
		end
		return
	end

	-- A hostile player damaged you.
	if dstGUID == playerGUID
		and srcName
		and TaliaaThreatIsHostilePlayer(srcFlags, srcGUID)
	then
		local fight = VoidMark:StartThreatFight(srcName)
		if fight then
			fight.damageTaken = fight.damageTaken + amount
			fight.lastEventTime = now
			fight.lastTakenTime = now
		end
	end
end

SLASH_TALIAATHREAT1 = "/tthreat"
SlashCmdList["TALIAATHREAT"] = function(msg)
	local command = strlower(msg or "")

	if command == "" or command == "status" then
		local count = 0
		for _ in pairs(VoidMark.ThreatCombat) do
			count = count + 1
		end
		DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00[Taliaa Threat]|r Active fights: " .. count)
		return
	end

	if command == "debug" then
		VoidMark.ThreatDebug = not VoidMark.ThreatDebug
		DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00[Taliaa Threat]|r Debug: " .. tostring(VoidMark.ThreatDebug))
		return
	end

	if command == "target" then
		local name, realm = VMAPI.UnitName("target")
		if not name then
			DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00[Taliaa Threat]|r No target.")
			return
		end

		if realm and realm ~= "" then
			name = name .. "-" .. realm
		end

		local playerData = VoidMarkPerCharDB
			and VoidMarkPerCharDB.PlayerData
			and VoidMarkPerCharDB.PlayerData[name]

		if not playerData or not playerData.threatData then
			DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00[Taliaa Threat]|r No threat data for " .. name)
			return
		end

		local threat = playerData.threatData
		local wins = threat.wins or 0
		local losses = threat.losses or 0
		local disengaged = threat.disengaged or 0
		local interrupted = threat.interrupted or 0
		local encounters = threat.fights or 0
		local completed = wins + losses
		local winRate = 0
		local avgEncounter = 0
		local avgWin = 0
		local avgLoss = 0

		if completed > 0 then
			winRate = (wins / completed) * 100
		end
		if encounters > 0 then
			avgEncounter = (threat.totalCombatTime or 0) / encounters
		end
		if wins > 0 then
			avgWin = (threat.totalWinTime or 0) / wins
		end
		if losses > 0 then
			avgLoss = (threat.totalLossTime or 0) / losses
		end

		local score, level, confidence = VoidMark:CalculateThreatScore(name)
		local _, threatColor = TaliaaThreatLabel(score)

		DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00[Taliaa Threat]|r " .. name)
		DEFAULT_CHAT_FRAME:AddMessage(string.format(
			"|cff00ff00[Taliaa Threat]|r Threat: %s%s %d/100|r | Confidence: %s",
			threatColor,
			level,
			score,
			confidence
		))
		DEFAULT_CHAT_FRAME:AddMessage(string.format(
			"|cff00ff00[Taliaa Threat]|r Record: %dW-%dL | Completed: %d | Win Rate: %.0f%%",
			wins,
			losses,
			completed,
			winRate
		))
		DEFAULT_CHAT_FRAME:AddMessage(string.format(
			"|cff00ff00[Taliaa Threat]|r Avg Encounter: %.1fs | Avg Win: %.1fs | Avg Loss: %.1fs",
			avgEncounter,
			avgWin,
			avgLoss
		))
		DEFAULT_CHAT_FRAME:AddMessage(string.format(
			"|cff00ff00[Taliaa Threat]|r Damage Done: %d | Taken: %d",
			threat.damageDone or 0,
			threat.damageTaken or 0
		))
		DEFAULT_CHAT_FRAME:AddMessage(string.format(
			"|cff00ff00[Taliaa Threat]|r Disengaged: %d | Interrupted: %d | Total Encounters: %d",
			disengaged,
			interrupted,
			encounters
		))
		return
	end

	DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00[Taliaa Threat]|r Commands: /tthreat status, /tthreat target, /tthreat debug")
end

--------------------------------------------------
-- END TALIAA SPY THREAT TRACKING
--------------------------------------------------


-- Close unresolved PvP encounters only after 15 seconds without
-- direct damage between you and that enemy.
local TaliaaThreatTimeoutFrame = CreateFrame("Frame")
local TaliaaThreatTimeoutElapsed = 0

TaliaaThreatTimeoutFrame:SetScript("OnUpdate", function(self, elapsed)
	TaliaaThreatTimeoutElapsed = TaliaaThreatTimeoutElapsed + elapsed
	if TaliaaThreatTimeoutElapsed < 1 then
		return
	end
	TaliaaThreatTimeoutElapsed = 0

	local now = GetTime()
	local expired = {}

	for player, fight in pairs(VoidMark.ThreatCombat) do
		if fight.lastEventTime and (now - fight.lastEventTime) >= TALIAA_THREAT_FIGHT_TIMEOUT then
			table.insert(expired, player)
		end
	end

	for _, player in ipairs(expired) do
		VoidMark:FinishThreatFight(player, "DISENGAGED")
	end
end)

function VoidMark:CombatLogEvent(info, timestamp, event, hideCaster, srcGUID, srcName, srcFlags, sourceRaidFlags, dstGUID, dstName, dstFlags, destRaidFlags, ...)
timestamp, event, hideCaster, srcGUID, srcName, srcFlags, sourceRaidFlags, dstGUID, dstName, dstFlags, destRaidFlags, arg12, arg13, arg14, arg15, arg16 = VMAPI.CombatLogGetCurrentEventInfo()
	if VoidMark.EnabledInZone then
		
		--PetKill code start
		combatEvent = {
			["SWING_DAMAGE"] = true,
			["RANGE_DAMAGE"] = true,
			["SPELL_DAMAGE"] = true,
			["SPELL_PERIODIC_DAMAGE"] = true,
		}	
		local spellID, spellName, spellSchool, amount, overkill 
		local petName = VMAPI.UnitName("pet"); 
		local _, overkill 	
		overkill = 0;		--PetKill code end
	
		-- analyse the source unit
		if bit.band(srcFlags, COMBATLOG_OBJECT_REACTION_HOSTILE) == COMBATLOG_OBJECT_REACTION_HOSTILE and srcGUID and srcName and not VoidMarkPerCharDB.IgnoreData[srcName] then
			local srcType = strsub(srcGUID, 1,6)
			if srcType == "Player" then
				local _, class, race, raceFile, _, name = VMAPI.GetPlayerInfoByGUID(srcGUID)
				if not VoidMark.ValidClasses[class] then
					class = nil
				end	
				if not VoidMark.ValidRaces[raceFile] then
					race = nil
				end
				local learnt = false
				local detected = true
				local playerData = VoidMarkPerCharDB.PlayerData[srcName]
				if not playerData or playerData.isGuess then
					learnt, playerData = VoidMark:ParseUnitAbility(true, event, srcName, class, race, arg12, arg13)
				end
				if not learnt then
					detected = VoidMark:UpdatePlayerData(srcName, class, nil, race, nil, nil, true, nil, nil)
				end

				if detected then
					VoidMark:AddDetected(srcName, timestamp, learnt)
					if event == "SPELL_AURA_APPLIED" and (arg13 == L["Stealth"]) then
						VoidMark:PromoteStealthPlayer(srcName, timestamp, "Stealth")
						VoidMark:AlertStealthPlayer(srcName)
					end	
					if event == "SPELL_AURA_APPLIED" and (arg13 == L["Prowl"]) then
						VoidMark:PromoteStealthPlayer(srcName, timestamp, "Prowl")
						VoidMark:AlertProwlPlayer(srcName)
					end
				end
			end

			if dstGUID == VMAPI.UnitGUID("player") then
				VoidMark.LastAttack = srcName
				VoidMark.LastAttackTime = GetTime()
			end
		end

		-- analyse the destination unit
		if bit.band(dstFlags, COMBATLOG_OBJECT_REACTION_HOSTILE) == COMBATLOG_OBJECT_REACTION_HOSTILE and dstGUID and dstName and not VoidMarkPerCharDB.IgnoreData[dstName] then
			local dstType = strsub(dstGUID, 1,6)
			if dstType == "Player" then
				local _, class, race, raceFile, _, name = VMAPI.GetPlayerInfoByGUID(dstGUID)
				if not VoidMark.ValidClasses[class] then
					class = nil
				end	
				if not VoidMark.ValidRaces[raceFile] then
					race = nil
				end				
				local learnt = false
				local detected = true
				local playerData = VoidMarkPerCharDB.PlayerData[dstName]
				if not playerData or playerData.isGuess then
					learnt, playerData = VoidMark:ParseUnitAbility(false, event, dstName, class, race, arg12, arg13)
				end
				if not learnt then
					detected = VoidMark:UpdatePlayerData(dstName, class, nil, race, nil, nil, true, nil, nil)
				end
				if detected then
					VoidMark:AddDetected(dstName, timestamp, learnt)
				end
			end
		end

		-- Taliaa VoidMark: track direct player-vs-player damage using VoidMark's existing combat event
		if combatEvent[event] then
			TaliaaThreatTrackDamage(event, srcGUID, srcName, srcFlags, dstGUID, dstName, dstFlags, arg12, arg13, arg14, arg15)
		end

		-- Gank Tracker assist credit:
		-- If a hostile player dies while we have an active Taliaa threat fight
		-- with them, count the gank even when somebody else got the killing blow.
		if event == "UNIT_DIED" and dstName and dstGUID then
			-- Classic Era 1.15.9 observation: a real Hunter death sends PARTY_KILL
			-- before UNIT_DIED; Feign sends UNIT_DIED alone with unconscious=false.
			-- GankTracker remembers the authoritative PARTY_KILL signal.
			if TaliaaGankTracker and TaliaaGankTracker.ShouldSuppressHunterUnitDied
				and TaliaaGankTracker:ShouldSuppressHunterUnitDied(dstName, dstGUID) then
				if TaliaaGankTracker.HandleHunterUnitDied then
					TaliaaGankTracker:HandleHunterUnitDied(dstGUID, dstName)
				end
				VoidMark.GankRecentDamage[dstName] = nil
				return
			end

			-- Hunter Feign can be identified by the unconsciousOnDeath flag when
			-- present, or by the live-unit fallback when the client omits it.
			local feignDetected = (arg13 == 1 or arg13 == true or arg13 == "1")
			if not feignDetected and TaliaaGankTracker and TaliaaGankTracker.IsUnitCurrentlyFeigningName then
				feignDetected = TaliaaGankTracker:IsUnitCurrentlyFeigningName(dstName)
			end
			if feignDetected then
				if TaliaaGankTracker and TaliaaGankTracker.HandleHunterFeign then
					TaliaaGankTracker:HandleHunterFeign(dstGUID, dstName)
				end
				VoidMark.GankRecentDamage[dstName] = nil
				return
			end

			-- UNIT_DIED / PARTY_KILL flags are not always identical in Classic.
			-- GUID is the reliable player test; VoidMark's database confirms enemy status.
			local isPlayerVictim = strsub(dstGUID, 1, 6) == "Player"
			local playerData = VoidMarkPerCharDB
				and VoidMarkPerCharDB.PlayerData
				and VoidMarkPerCharDB.PlayerData[dstName]
			local isEnemyVictim = playerData and playerData.isEnemy

			local recentDamage = VoidMark.GankRecentDamage[dstName]
			local recentlyEngaged = recentDamage
				and (GetTime() - recentDamage) <= VOIDMARK_GANK_CREDIT_WINDOW

			if isPlayerVictim and isEnemyVictim
				and (recentlyEngaged or VoidMark.ThreatCombat[dstName])
			then
				-- Count the gank immediately, even if somebody else got the KB.
				if TaliaaGankTracker and TaliaaGankTracker.RecordKill then
					TaliaaGankTracker:RecordKill(dstName, dstGUID, false)
				end
				VoidMark.GankRecentDamage[dstName] = nil

				-- Do NOT close the threat fight immediately. PARTY_KILL can arrive
				-- just after UNIT_DIED. Give it a moment so a real KB becomes WIN.
				if VoidMark.ThreatCombat[dstName] then
					local deadName = dstName
					C_Timer.After(0.30, function()
						if VoidMark.ThreatCombat[deadName] then
							VoidMark:FinishThreatFight(deadName, "INTERRUPTED")
						end
					end)
				end
			end
		end

		-- Feign Death is reported as an unconscious kill-credit event.
		-- Stop it before the normal PARTY_KILL path can record a real gank.
		-- arg13 is unconsciousOnDeath for PARTY_KILL.
		if event == "PARTY_KILL" and dstName and dstGUID then
			-- PARTY_KILL stores unconsciousOnDeath in arg16 on Classic's
			-- combat-log payload. Keep arg13 as a compatibility fallback.
			local feignDetected = (arg16 == 1 or arg16 == true or arg16 == "1"
				or arg13 == 1 or arg13 == true or arg13 == "1")
			if not feignDetected and TaliaaGankTracker and TaliaaGankTracker.IsUnitCurrentlyFeigningName then
				feignDetected = TaliaaGankTracker:IsUnitCurrentlyFeigningName(dstName)
			end
			if feignDetected then
				if TaliaaGankTracker and TaliaaGankTracker.HandleHunterFeign then
					TaliaaGankTracker:HandleHunterFeign(dstGUID, dstName)
				end
				VoidMark.GankRecentDamage[dstName] = nil
				return
			end
		end

		-- SPELL_INSTAKILL also carries unconsciousOnDeath in arg16.
		if event == "SPELL_INSTAKILL" and dstName and dstGUID
			and (arg16 == 1 or arg16 == true or arg16 == "1") then
			if TaliaaGankTracker and TaliaaGankTracker.HandleHunterFeign then
				TaliaaGankTracker:HandleHunterFeign(dstGUID, dstName)
			end
			VoidMark.GankRecentDamage[dstName] = nil
			return
		end

		-- update win stats / Gank Tracker
		if event == "PARTY_KILL" then
			-- PARTY_KILL fires when YOU OR A GROUP MEMBER gets the killing blow.
			-- The tracker should count the group gank, while threat W/L stays personal.
			local isPlayerVictim = dstGUID and strsub(dstGUID, 1, 6) == "Player"

			local playerData = dstName and VoidMarkPerCharDB
				and VoidMarkPerCharDB.PlayerData
				and VoidMarkPerCharDB.PlayerData[dstName]

			-- Use either VoidMark's known-enemy flag or combat-log hostility.
			local hostileByDB = playerData and playerData.isEnemy
			local hostileByFlags = dstFlags
				and bit.band(dstFlags, COMBATLOG_OBJECT_REACTION_HOSTILE) > 0
			local isEnemyVictim = hostileByDB or hostileByFlags

			-- Accept kills credited to us, our pet/guardian, party, or raid.
			local sourceIsGroup = srcFlags and (
				bit.band(srcFlags, COMBATLOG_OBJECT_AFFILIATION_MINE) > 0
				or bit.band(srcFlags, COMBATLOG_OBJECT_AFFILIATION_PARTY) > 0
				or bit.band(srcFlags, COMBATLOG_OBJECT_AFFILIATION_RAID) > 0
			)

			local sourceIsPlayer = srcGUID == VMAPI.UnitGUID("player")

			if dstName and isPlayerVictim and isEnemyVictim and sourceIsGroup then
				-- PARTY_KILL is authoritative real-death evidence. Confirm a Hunter
				-- before RecordKill so the following UNIT_DIED cannot race into Feign.
				if TaliaaGankTracker and TaliaaGankTracker.ConfirmHunterRealDeath then
					TaliaaGankTracker:ConfirmHunterRealDeath(dstGUID, dstName)
				end
				if TaliaaGankTracker and TaliaaGankTracker.RecordKill then
					TaliaaGankTracker:RecordKill(dstName, dstGUID, sourceIsPlayer)
				end
				VoidMark.GankRecentDamage[dstName] = nil

				-- Personal threat WIN only when YOUR character got the KB.
				-- Lifetime wins are owned by GankRepository/RecordKill; do not
				-- increment PlayerData.wins here or the same death is counted twice.
				if sourceIsPlayer then
					if VoidMark.ThreatCombat[dstName] then
						VoidMark:FinishThreatFight(dstName, "WIN")
					end
				end
			end
		end

		-- adds pet kills to the win stats
		if combatEvent[event] then
			if event == "SWING_DAMAGE" then
				if arg13 == nil then
					overkill = 0
				else
					overkill = arg13
				end
			else
				if arg16 == nil then
					overkill = 0
				else
					overkill = arg16
				end
			end
			if (overkill > 1) and dstName then
				if VoidMark.PetGUID[srcGUID] then
					local playerData = VoidMarkPerCharDB.PlayerData[dstName]
					if playerData then
						-- RecordKill/GankRepository owns lifetime win accounting.
						-- Pet/guardian killing blows may still finish the personal
						-- threat fight, but must not increment PlayerData.wins.
						if VoidMark.ThreatCombat[dstName] then
							VoidMark:FinishThreatFight(dstName, "WIN")
						end
--							DEFAULT_CHAT_FRAME:AddMessage("Your pet/guardian killed " .. dstName);
					end
				end
			end
		end
		if event == "SPELL_SUMMON" and srcName == VoidMark.CharacterName then
			local petGUID = dstGUID
			VoidMark.PetGUID[petGUID] = time()
		end
		if event == "ENVIRONMENTAL_DAMAGE" and dstGUID == VMAPI.UnitGUID("player") then
--			local environmentalType = arg12
--			local amount = arg13
			VoidMark.LastAttack = nil		
--			print(timestamp, "Ouch ", environmentalType, amount, " hurts!")
		end		
	end
end

function VoidMark:LeftCombatEvent()
	VoidMark.LastAttack = nil
	-- Do not close Taliaa threat fights here.
	-- Classic Era players can briefly leave combat and immediately re-engage.
	VoidMark:RefreshCurrentList()
	if VoidMark.ClearCombatSightings then
		VoidMark:ClearCombatSightings()
	end
end

function VoidMark:PlayerDeadEvent()
	if VoidMark:ShouldIgnoreBattlegroundStats() then
		-- Drop any active fight state without writing BG losses/fight records.
		VoidMark.ThreatCombat = {}
		return
	end
	-- Taliaa VoidMark: use the most recent hostile-player damage within 10 seconds
	-- as the loss owner. The old VoidMark path required the final hostile event to land
	-- within 0.5s of PLAYER_DEAD, which missed many normal PvP deaths and left the
	-- compact lifetime record's loss side artificially low.
	local now = GetTime()
	local killer = nil
	local newestHit = 0

	for player, fight in pairs(VoidMark.ThreatCombat) do
		if fight.lastTakenTime then
			local age = now - fight.lastTakenTime
			if age <= TALIAA_THREAT_DEATH_CREDIT_WINDOW and fight.lastTakenTime > newestHit then
				newestHit = fight.lastTakenTime
				killer = player
			end
		end
	end

	if killer then
		local playerData = VoidMarkPerCharDB and VoidMarkPerCharDB.PlayerData and VoidMarkPerCharDB.PlayerData[killer]
		if playerData then
			playerData.loses = (tonumber(playerData.loses) or 0) + 1
		end

		VoidMark:FinishThreatFight(killer, "LOSS")

		-- Any other active enemy encounters were not responsible for the death.
		if next(VoidMark.ThreatCombat) then
			VoidMark:FinishAllThreatFights("INTERRUPTED")
		end
	else
		-- Player died, but no active enemy player qualifies for kill credit
		-- (guards, mobs, environment, etc.). Preserve the encounter as interrupted.
		if next(VoidMark.ThreatCombat) then
			VoidMark:FinishAllThreatFights("INTERRUPTED")
		end
	end
end

function VoidMark:UnitPets(event, unit)
	local petUnit
	if unit == "player" then
		petUnit = "pet"
	end
	if petUnit and VMAPI.UnitExists(petUnit) then
		local guid = VMAPI.UnitGUID(unit)
		local petGUID = VMAPI.UnitGUID(petUnit)
		VoidMark.PetGUID[petGUID] = time()
		local petCount = 0
		for k, v in pairs(VoidMark.PetGUID) do
			petCount = petCount + 1
			if petCount > 50 then
				if (time() - 9000) > v then
					VoidMark.PetGUID[k] = nil
				end	
			end
		end	
	end
end

function VoidMark:CommReceived(prefix, message, distribution, source)
	-- Removed: VoidMark no longer imports encounter data from other VoidMark users.
	return
end

function VoidMark:VersionCheck(version1, version2)
	local major1, minor1, update1 = strsplit(".", version1)
	local major2, minor2, update2 = strsplit(".", version2)
	major1, minor1, update1 = tonumber(major1), tonumber(minor1), tonumber(update1)
	major2, minor2, update2 = tonumber(major2), tonumber(minor2), tonumber(update2)
	if major1 < major2 then
		return true
	elseif ((major1 == major2) and (minor1 < minor2)) then
		return true
	elseif ((major1 == major2) and (minor1 == minor2) and (update1 < update2)) then
		return true
	else	
		return false
	end
end

function VoidMark:TrackHumanoids()
	-- Removed: legacy minimap tooltip scanning is disabled.
	return
end

function VoidMark:FilterNotInParty(frame, event, message)
	if (event == ERR_NOT_IN_GROUP or event == ERR_NOT_IN_RAID) then
		return true
	end
	return false
end

function VoidMark:ShowMapNote(player)
	-- Removed: VoidMark does not create world-map/minimap enemy pins.
	return
end

function VoidMark:GetPlayerLocation(playerData)
	local location = playerData.zone
	local mapX = playerData.mapX
	local mapY = playerData.mapY
	if location and playerData.subZone and playerData.subZone ~= "" and playerData.subZone ~= location then
		location = playerData.subZone..", "..location
	end
	if mapX and mapX ~= 0 and mapY and mapY ~= 0 then
		location = location.." ("..math.floor(tonumber(mapX) * 100)..","..math.floor(tonumber(mapY) * 100)..")"
	end
	return location
end

function VoidMark:HideVoidMarkCombatCheck()
	if InCombatLockdown() then
		-- MainWindow did not Hide while in combat, try again in 10 seconds.
		self:ScheduleTimer("HideVoidMarkCombatCheck",10)
		return
	else
		VoidMark.MainWindow:Hide()
	end
end

function VoidMark:FormatTime(timestamp)
    if timestamp == 0 then return "Long " end

    local age = time() - timestamp

    local days
    if age >= 86400 then
        days = math.modf(age / 86400)
        age = age - (days * 86400)
    end

    local hours
    if age >= 3600 then
        hours = math.modf(age / 3600)
        age = age - (hours * 3600)
    end

    local minutes
    if age >= 60 then
        minutes = math.modf(age / 60)
        age = age - (minutes * 60)
    end

    local seconds = age

    local text = (days and days .. "d " or "") .. ((hours and not days) and hours .. "h " or "") .. ((minutes and not hours and not days) and minutes .. "m " or "") .. ((seconds and not minutes and not hours and not days) and seconds .. "s " or "")

    return strtrim(text)
end

-- recieves pointer to VoidMarkData VoidMark_db
function VoidMark:SetDataDb(val)
    VoidMark_db = val
end
